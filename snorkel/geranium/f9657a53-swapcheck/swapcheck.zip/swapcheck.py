#!/usr/bin/env python3
# October swap queue per rotation_rules.txt, worked top to bottom
#   python3 swapcheck.py roster.csv swaps.csv > swap_report.txt

import csv
import sys
from datetime import date, timedelta

if len(sys.argv) != 3:
    sys.exit("usage: swapcheck.py roster.csv swaps.csv")

MAX_NIGHTS = 4


def d(s):
    y, m, dd = s.strip().split("-")
    return date(int(y), int(m), int(dd))


with open(sys.argv[1], newline="") as f:
    rota = {(d(r["shift_date"]), r["slot"].strip()): r["engineer"].strip() for r in csv.DictReader(f)}
with open(sys.argv[2], newline="") as f:
    queue = list(csv.DictReader(f))

published = sorted(set(rota.values()))    # s.6: these all get a count line
joined = []                               # plus anyone a swap brings in


def nights(r, who):
    return sum(1 for (_, s), e in r.items() if s == "night" and e == who)


def bad_turnaround(r, who):
    # night then the next morning's day slot
    return any(s == "night" and e == who and r.get((dy + timedelta(days=1), "day")) == who
               for (dy, s), e in r.items())


log = []
ok = no = 0
for q in queue:
    sid, frm, to = q["swap_id"].strip(), q["requester"].strip(), q["counterparty"].strip()
    dy, slot = d(q["shift_date"]), q["slot"].strip()
    other = "night" if slot == "day" else "day"

    # s.4 order: same person, stale, night cap, turnaround
    why = ""
    if frm == to:
        why = "same person"
    elif rota.get((dy, slot)) != frm:
        why = "stale"
    else:
        swap = rota.get((dy, other)) == to
        trial = dict(rota)
        trial[(dy, slot)] = to
        if swap:
            trial[(dy, other)] = frm
        # both people, on the roster with the whole move in place (s.7)
        if nights(trial, frm) > MAX_NIGHTS or nights(trial, to) > MAX_NIGHTS:
            why = "night cap"
        elif bad_turnaround(trial, frm) or bad_turnaround(trial, to):
            why = "turnaround"

    if why:
        no += 1
        log.append("  %-8s refused %s" % (sid, why))
        continue

    rota = trial
    ok += 1
    if to not in published and to not in joined:
        joined.append(to)
    moved = "%s %s to %s" % (dy.isoformat(), slot, to)
    if swap:
        moved += ", %s %s to %s" % (dy.isoformat(), other, frm)
    log.append("  %-8s applied  %s" % (sid, moved))

print("swap queue worked against roster.csv")
print("requests %d, applied %d, refused %d" % (len(queue), ok, no))
print()
print("\n".join(log))
print()
print("night counts")
tally = {}
for who in sorted(published + joined):
    tally[who] = nights(rota, who)
    print("  %-14s %d" % (who, tally[who]))
print()
print("settled roster")
for dy in sorted({k[0] for k in rota}):
    for slot in ("day", "night"):
        print("  %s  %-6s %s" % (dy.isoformat(), slot, rota[(dy, slot)]))

sys.stderr.write("shifts=%d requests=%d applied=%d refused=%d nights_max=%d\n"
                 % (len(rota), len(queue), ok, no, max(tally.values())))
