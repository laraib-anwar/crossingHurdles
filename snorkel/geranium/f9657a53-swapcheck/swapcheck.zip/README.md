# swapcheck

Works the October swap queue, judging each request against the roster
as it stands at that point, per rotation_rules.txt. Run:

    python3 swapcheck.py roster.csv swaps.csv

The report goes to stdout and one line goes to stderr:

    shifts=62 requests=28 applied=20 refused=8 nights_max=4

swap_report.txt is that run, a short note first and then the report in
full: the per request verdicts, the closing night counts, and the
settled roster.

What to watch for. Every request is judged against the roster as it
stands when its turn comes, never against the published one. That is
the whole job and it is the easy thing to get wrong: judge each
request on its own against the published rotation instead and seven
of the twenty eight verdicts flip, s-208, s-211, s-212, s-215, s-221,
s-224 and s-227, leaving 23 applied where 20 should be.
One request names a night an earlier request already moved, so it is
stale rather than wrong.

A refused request changes nothing at all, which matters more than it
sounds. Because the roster does not move, capacity that a refusal
leaves behind is still there for a later request, and both night cap
refusals, s-221 and s-227, only happen because earlier swaps pushed
someone up to four. Applying a refused request "just a little", or carrying a
partial trade, leaves a roster the rules never produced, and any
verdict after it can come out wrong.

Both halves of a trade are judged together. The cap and the turnaround
rule are checked on the roster as it would stand with the whole swap
in place, and for both people, so a swap can be refused because of the
person receiving the shift while the person handing it over is nowhere
near either limit. Check that first if a rebuild disagrees with this
report.

If you change the queue or the roster, rerun and diff against the
committed report before anyone is paged off it. The per request
verdicts move before the settled roster visibly does.
