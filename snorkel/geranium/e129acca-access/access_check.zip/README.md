# access_check

Answers support tickets about player access, per access_rules.txt. Run
it with the four csv paths in order and the as of date last:

    python3 access_check.py catalog.csv transactions.csv subscriptions.csv queries.csv 2026-07-20

The whole report goes to stdout: the header line, one line per ticket
in queries.csv order, the per reason counts, and a final totals line.
The same totals line is repeated on stderr so whoever runs it sees the
batch shape even when stdout is redirected to a file. decisions.txt in
this folder is that 2026-07-20 run exactly as the script printed it, 77
tickets, 38 with access and 39 without, beginning at the header line,
so it diffs straight against a rerun.

A cancelled closure is the newest trap. A transfer_cancel row recalls
the closed account's own rows from wherever the chain has carried them
and reopens the account, but it recalls nothing that merely travelled
with them, so one account here gets its purchase back from two hops
away while its old partner's purchase stays put.

Transfer dates are the thing to get right, and they are easy to miss.
Transfers settle in the order they happened, two on one date going in
the order transactions.csv lists them, and each one carries only
what the closing account held on that day, so an account that moved
out in May and received another history in June keeps what arrived:
it does not forward it on to the account it left for. Chase the names
without reading the dates and a chain looks like it runs the whole
way when it really stopped one stop short. Rings are the exception:
once the transfers that have happened by the as of date close a loop,
it is refused whatever order they ran in. A closure that was called
back is not part of a ring though. The cancel reopens the account and
takes the edge with it, so the next transfer that account files is
the one that counts.

Bundles can contain other bundles. The vault set covers the duo pack
and one game, so its buyer holds the duo pack titles through two
covers links, and the reason stays bundle however deep the chain goes.
The catalog even carries two sets that name each other, sku-tidewater-box and
sku-lantern-box, and the tool works through that loop by following each
link once. A chargeback kills the purchase it touches and nothing
else, but when that purchase was a set reaching a game through covers,
the route it carried dies with it. That is why a lowtide ticket in the batch comes
back charged back with no direct lowtide purchase anywhere in that player's settled history: the
set was that player's only route to the game, so killing the set's
purchase killed the route.

Expansions are the newest rule and the one that makes the tool
recursive. A title with a requires entry only grants while the title
it names is live for the same player, and live means the full verdict
of these rules, not the presence of a purchase. So settling an
expansion means judging its own paths first and then, only when one of
them is live, settling the title it requires, and if that title is
itself an expansion, its base too, until a game is reached. Do it as a call
back into the same settle routine with the chain so far passed along,
so a catalog ring stops instead of recursing forever. The trap in
this batch is the two level chain where the player owns the middle
title: a one level check finds that purchase and says yes, and the
right answer is no, because the middle title's own base lapsed.
Order matters too: the expansion's own paths are judged first, so a
refunded expansion reports the refund and never looks at its base.

Promo keys are the other place paths do not stand alone, and it is the
rule most likely to be skipped. A key is spent the moment the same
history holds a purchase of that title dated on or after the grant,
and a spent key is not a path at all, so refunding that purchase
leaves the player with a dead purchase and nothing else. Order is
everything: a purchase made before the key was issued spends nothing,
and that key survives the refund of the earlier purchase. The spent
state travels with the history too, so an inherited key that arrived
alongside the purchase that spent it arrives spent. Three tickets near
the end of the batch turn on this. larch_bay's key was spent by a later
purchase, so it answers REFUNDED rather than VIA_PROMO, and kite_marsh
inherited a spent key with its chargeback. wren_holt is the contrast:
its purchase came before the key, so the key survives the refund and it
answers VIA_PROMO.

The part that takes care, learned while testing: paths live and die on
their own otherwise. A chargeback kills the purchase it touches and nothing
else, so a player who charged back a bundle and then cleanly bought
one of its games keeps that game, and the same player can still reach
another bundle title through an active subscription. A refunded
bundle takes its members down unless a member was also bought
directly. Region locks kill purchase, bundle, edition, and promo
paths whose region doesn't match, but subscriptions don't care about
region, which is why a jp locked title can still come back as VIA_SUB
for a subscriber who never bought it.

Refunds and chargebacks settle against the most recent purchase of
that sku on or before their own date. That one sentence in the rules
does a lot of work. It is why a refund followed by a fresh repurchase
leaves the player owning the game, and it is why a purchase that
collected both a refund and a chargeback reports CHARGEBACK, the
higher ranked of the two, no matter which row the export happens to
list first. The export's row order decides nothing except in the two
places the rules hand it a job. Two transfers dated the same day settle
in the order the file lists them, and where a player bought the same sku
twice on the same most recent date, a refund or chargeback settles
against the purchase the file lists last. Everywhere else the dates
decide, except inside a ring, which is refused whatever order its
transfers ran in.

Dates are boundary inclusive on every comparison. A subscription
ending on the as of date is still good that day, a promo expiring on
the as of date still grants that day, and both flip the day after.
The other side of that coin is the future: a transaction dated past
the as of date has not happened yet, so it neither grants nor kills.
There is a purchase in this batch dated in August, and as of 2026-07-20
the right answer for that player is NO_GRANT, not OWNED. That one
burned the first draft of this script.

When everything a player had is dead, the reason that comes back is
the strongest one on the blocker list, so a refund outranks a lapsed
subscription, a region mismatch outranks an expired promo even when
the same promo is both, and a lapsed subscription outranks an expired
promo. On the access side the same idea runs the other way, owning a
game beats holding it through a bundle, and an edition beats a
subscription that covers the same title.

The history also carries players, skus, and
whole transactions that no ticket asks about. The tool decides the
tickets in queries.csv and nothing else, so those rows are simply
never mentioned in the report. If a new batch comes in, only
queries.csv changes and the same command runs it.

Transfers are the piece that will break a straight per player lookup.
An account's history moves whole to the account it transferred to
unless the two name each other, and those moves chain only as far as
the dates allow, so answering a ticket means first working out where
each history finally sits, or that it sits nowhere at all, and only
then walking the grant paths. In this batch that chain runs two hops,
and a tool that resolves one hop reports no grant for a player who
genuinely holds the title, and reports access for the account in the
middle that holds nothing at all. Dead paths travel with the history, so a refunded purchase still
reports the refund after it changes hands. Two accounts that name each
other settle nowhere and every ticket against them answers transfer
loop, which sits above every other blocker because there is no history
to reason about. And a transfer dated after the as of date has not
happened, so it moves nothing.
