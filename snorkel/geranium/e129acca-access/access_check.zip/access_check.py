#!/usr/bin/env python3
# access_check.py - answers the queue's "why can't I play X" tickets off the
# store exports. the rules live in access_rules.txt, sec numbers below point
# there.
#
#   python3 access_check.py catalog.csv transactions.csv subscriptions.csv queries.csv 2026-07-20
#
# changes
#   07-02  refund/chargeback hits the latest buy on or before it, not the first
#   07-09  transfer_cancel (quill_dora). own rows come back, nothing else does
#   07-15  promo keys get spent by a later buy (larch_bay, kite_marsh)
#   07-18  expansions need a live base, recursive, chain passed down so the
#          catalog loop cant spin forever
#   07-20  rows dated after the as of date are skipped. the august buy is why

import csv, sys
from datetime import date

if len(sys.argv) != 6:
    sys.exit('usage: access_check.py catalog.csv transactions.csv subscriptions.csv queries.csv YYYY-MM-DD')


def ymd(s):
    y, m, d = s.strip().split('-')
    return date(int(y), int(m), int(d))

def load(fn):
    f = open(fn, newline='')
    out = []
    for r in csv.DictReader(f):
        for k in r:
            r[k] = (r[k] or '').strip()
        out.append(r)
    f.close()
    return out


asof = ymd(sys.argv[5])

cat = {}
for r in load(sys.argv[1]):
    cat[r['sku_id']] = r

tx = []     # on/before asof only, r['i'] keeps the file position
i = 0
for r in load(sys.argv[2]):
    r['i'] = i
    r['d'] = ymd(r['date'])
    i = i + 1
    if r['d'] > asof:
        continue        # hasnt happened yet (sec 5)
    tx.append(r)

subs = load(sys.argv[3])
queries = load(sys.argv[4])

buys, moves = [], []
for r in tx:
    if r['kind'] == 'purchase':
        buys.append(r)
    if r['kind'] in ('transfer', 'transfer_cancel'):
        moves.append(r)
moves.sort(key=lambda r: (r['d'], r['i']))     # same day -> file order


# --- rings (sec 3)
# first move out of an account is its edge. a cancel takes it away and the
# next transfer that account files is the edge instead. no dates on purpose,
# a loop is a loop once all its edges have happened
nxt = {}
for r in moves:
    who = r['player']
    if r['kind'] == 'transfer_cancel':
        if who in nxt:
            del nxt[who]
    elif not who in nxt:
        nxt[who] = r['sku']

loop = set()
for a in nxt:
    seen = [a]
    b = nxt[a]
    while b in nxt and b not in seen:
        seen.append(b)
        b = nxt[b]
    if b in seen:
        # just the cycle, an account feeding into it isnt part of it
        for x in seen[seen.index(b):]:
            loop.add(x)


# --- whose rows are where (sec 3)
# opn[acct] = [from, to] spans the account was open. its own rows only count
# when they fall inside one, which is what stops rows dated while it was
# closed from coming back on a cancel.
# has[acct] = accounts whose rows sit with acct right now
opn = {}
has = {}
for r in tx:
    names = [r['player']]
    if r['kind'] == 'transfer':
        names.append(r['sku'])
    for a in names:
        if a not in opn:
            opn[a] = [[None, None]]
            has[a] = set([a])

closed = set()
for r in moves:
    a = r['player']
    if r['kind'] == 'transfer_cancel':
        if a not in closed:
            continue
        for k in has.keys():
            if k != a and a in has[k]:
                has[k].remove(a)
        has[a].add(a)
        opn[a].append([r['d'], None])
        closed.remove(a)
        continue
    if a in closed or a in loop:
        continue
    # span gets closed first, ring target or not. the cancel opens a new
    # span on its own date so nothing dated in between is a's again
    opn[a][-1][1] = r['d']
    if not r['sku'] in loop:
        has[r['sku']] = has[r['sku']] | has[a]
    has[a] = set()
    closed.add(a)


def counts(grp, r):
    # is row r part of the history held by grp
    if r['player'] not in grp:
        return False
    for lo, hi in opn.get(r['player'], [[None, None]]):
        if (lo is None or r['d'] >= lo) and (hi is None or r['d'] <= hi):
            return True
    return False

def covers(pack, sku, done):
    # sets inside sets, and two of them name each other, so open each once
    done.add(pack)
    for p in cat.get(pack, {}).get('covers', '').split('+'):
        p = p.strip()
        if p == '':
            continue
        if p == sku:
            return 1
        if p not in done and covers(p, sku, done):
            return 1
    return 0


OK_ORDER = 'OWNED VIA_BUNDLE VIA_EDITION VIA_SUB VIA_PROMO'.split()
NO_ORDER = 'TRANSFER_LOOP NEEDS_BASE CHARGEBACK REFUNDED REGION_LOCK SUB_LAPSED PROMO_EXPIRED'.split()


def settle(pl, sku, chain=()):
    if pl in loop:
        return 'no access', 'TRANSFER_LOOP'
    grp = has.get(pl, set([pl]))
    c = cat.get(sku, {})
    lock = c.get('region_lock') or 'all'

    # refunds + chargebacks (sec 4): latest buy of that sku on or before the
    # event. two on the same date -> the one further down the file
    dead_buy = {}
    for e in tx:
        if e['kind'] != 'refund' and e['kind'] != 'chargeback':
            continue
        if not counts(grp, e):
            continue
        tgt = None
        for b in buys:
            if b['player'] == e['player'] and b['sku'] == e['sku'] and b['d'] <= e['d'] and counts(grp, b):
                if tgt == None or b['d'] >= tgt['d']:
                    tgt = b
        if tgt:
            why = e['kind'] == 'chargeback' and 'CHARGEBACK' or 'REFUNDED'
            dead_buy.setdefault(tgt['i'], []).append(why)

    good = []
    bad = []
    for b in buys:
        if not counts(grp, b):
            continue
        if b['sku'] == sku:
            via = 'OWNED'
        elif covers(b['sku'], sku, set()):
            k = cat[b['sku']]['kind']
            if k == 'bundle':
                via = 'VIA_BUNDLE'
            elif k == 'edition':
                via = 'VIA_EDITION'
            else:
                continue
        else:
            continue
        probs = dead_buy.get(b['i'], [])[:]
        if lock != 'all' and b['region'] != lock:
            probs.append('REGION_LOCK')
        if len(probs) > 0:
            bad.extend(probs)
        else:
            good.append(via)

    # subs dont move with a transfer and dont care about region (sec 2)
    if c.get('in_sub_catalog') == 'yes':
        for s in subs:
            if s['player'] == pl:
                if ymd(s['start']) <= asof and asof <= ymd(s['end']):
                    good.append('VIA_SUB')
                elif ymd(s['end']) < asof:
                    bad.append('SUB_LAPSED')

    # promo keys (sec 4). a buy of the title on/after the grant date uses the
    # key up, and a used key is gone even if that buy was refunded later
    for g in tx:
        if g['kind'] != 'promo_grant' or g['sku'] != sku:
            continue
        if not counts(grp, g):
            continue
        used = False
        j = 0
        while j < len(buys) and not used:
            b = buys[j]
            used = b['sku'] == sku and b['d'] >= g['d'] and counts(grp, b)
            j += 1
        if used:
            continue
        probs = []
        if not g['expires'] or ymd(g['expires']) < asof:
            probs.append('PROMO_EXPIRED')
        if lock != 'all' and g['region'] != lock:
            probs.append('REGION_LOCK')
        if probs:
            bad += probs
        else:
            good.append('VIA_PROMO')

    # print(pl, sku, good, bad)

    if good:
        # sec 7, expansions. base only gets looked at once there's a live path
        base = c.get('requires', '')
        if base:
            if base == sku or base in chain:
                return 'no access', 'NEEDS_BASE'
            if settle(pl, base, chain + (sku,))[0] != 'access':
                return 'no access', 'NEEDS_BASE'
        for x in OK_ORDER:
            if x in good:
                return 'access', x
    for x in NO_ORDER:
        if x in bad:
            return 'no access', x
    return 'no access', 'NO_GRANT'


lines = ['access decisions as of ' + asof.isoformat()]
n = {}
yes = 0
for q in queries:
    v, why = settle(q['player'], q['sku'])
    n[why] = n.get(why, 0) + 1
    if v == 'access':
        yes = yes + 1
    lines.append('  '.join([q['ticket'], q['player'], q['sku'], v, why]))
for x in OK_ORDER + NO_ORDER + ['NO_GRANT']:
    if x in n:
        lines.append('%s: %d' % (x, n[x]))
tot = 'tickets=%d access=%d no_access=%d' % (len(queries), yes, len(queries) - yes)
lines.append(tot)
print('\n'.join(lines))
sys.stderr.write(tot + '\n')
