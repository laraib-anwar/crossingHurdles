import sys, csv
from datetime import date

# answers player access tickets. usage:
#   access_check.py catalog.csv transactions.csv subscriptions.csv queries.csv 2026-07-20
# section numbers in the comments are access_rules.txt

args = sys.argv[1:]
if len(args) != 5:
    print("usage: access_check.py catalog.csv transactions.csv subscriptions.csv queries.csv YYYY-MM-DD", file=sys.stderr)
    sys.exit(1)


def day(text):
    y, m, d = text.strip().split("-")
    return date(int(y), int(m), int(d))


def rows(path):
    out = []
    with open(path, newline="") as fp:
        for row in csv.DictReader(fp):
            for k in row:
                row[k] = (row[k] or "").strip()
            out.append(row)
    return out


asof = day(args[4])
catalog = {}
for row in rows(args[0]):
    catalog[row["sku_id"]] = row

# file position is kept because it settles two transfers on one day and
# two buys of one sku on one day. a row dated after the as of date
# hasn't happened yet (sec 5)
txns = []
n = 0
for row in rows(args[1]):
    row["n"] = n
    row["on"] = day(row["date"])
    n += 1
    if row["on"] <= asof:
        txns.append(row)
subs = rows(args[2])
tickets = rows(args[3])

buys = []
moves = []
for t in txns:
    if t["kind"] == "purchase":
        buys.append(t)
    elif t["kind"] in ("transfer", "transfer_cancel"):
        moves.append(t)
moves.sort(key=lambda t: (t["on"], t["n"]))

# sec 3, rings. an account's first transfer out is its edge, a cancel
# drops the edge and whatever it files next counts instead. the dates
# don't matter for a ring, only whether the edges close a loop
edge = {}
for t in moves:
    if t["kind"] == "transfer_cancel":
        edge.pop(t["player"], None)
    elif t["player"] not in edge:
        edge[t["player"]] = t["sku"]

ring = set()
for start in edge:
    path = [start]
    nxt = edge[start]
    while nxt in edge and nxt not in path:
        path.append(nxt)
        nxt = edge[nxt]
    if nxt in path:
        ring.update(path[path.index(nxt):])   # the loop, not the way in

# sec 3, where each history ends up. spans[a] holds a's [opened, closed]
# dates and only a's rows inside a span ever move or come back.
# sits[a] is whose rows sit with a right now
spans = {}
sits = {}
for t in txns:
    names = [t["player"]]
    if t["kind"] == "transfer":
        names.append(t["sku"])
    for a in names:
        if a not in spans:
            spans[a] = [[None, None]]
            sits[a] = {a}

shut = set()
for t in moves:
    a = t["player"]
    if t["kind"] == "transfer_cancel":
        if a not in shut:
            continue   # never left, nothing to call back
        # a's own rows come home from wherever the chain took them,
        # anything that travelled with them stays put
        for b in sits:
            if b != a:
                sits[b].discard(a)
        sits[a].add(a)
        spans[a].append([t["on"], None])
        shut.discard(a)
        continue
    if a in shut or a in ring:
        continue
    # close date goes on even when the target sits in a ring, so a cancel
    # later can't recall anything dated while a was shut
    spans[a][-1][1] = t["on"]
    if t["sku"] not in ring:
        sits[t["sku"]] |= sits[a]
    sits[a] = set()
    shut.add(a)


def here(group, t):
    # t counts for whoever holds group if its owner is in the group and
    # it is dated inside one of the owner's open spans
    if t["player"] not in group:
        return False
    for lo, hi in spans.get(t["player"], [[None, None]]):
        if lo is not None and t["on"] < lo:
            continue
        if hi is not None and t["on"] > hi:
            continue
        return True
    return False


def reaches(pack, want, seen):
    # sets can cover sets and two in the catalog cover each other, so
    # each one is opened once
    seen.add(pack)
    for part in catalog.get(pack, {}).get("covers", "").split("+"):
        part = part.strip()
        if not part:
            continue
        if part == want:
            return True
        if part not in seen and reaches(part, want, seen):
            return True
    return False


# sec 6, strongest first
GRANTS = ["OWNED", "VIA_BUNDLE", "VIA_EDITION", "VIA_SUB", "VIA_PROMO"]
BLOCKS = ["TRANSFER_LOOP", "NEEDS_BASE", "CHARGEBACK", "REFUNDED",
          "REGION_LOCK", "SUB_LAPSED", "PROMO_EXPIRED"]


def settle(player, sku, chain=()):
    if player in ring:
        return "no access", "TRANSFER_LOOP"
    group = sits.get(player, {player})
    item = catalog.get(sku, {})
    lock = item.get("region_lock") or "all"

    # sec 4. a refund or chargeback lands on the newest buy of that sku
    # on or before its own date, the one listed last if two share it
    hit = {}
    for t in txns:
        if t["kind"] not in ("refund", "chargeback") or not here(group, t):
            continue
        target = None
        for b in buys:
            if b["player"] != t["player"] or b["sku"] != t["sku"] or b["on"] > t["on"]:
                continue
            if not here(group, b):
                continue
            if target is None or b["on"] >= target["on"]:
                target = b
        if target is None:
            continue
        if t["kind"] == "chargeback":
            hit.setdefault(target["n"], []).append("CHARGEBACK")
        else:
            hit.setdefault(target["n"], []).append("REFUNDED")

    live = []
    dead = []
    for b in buys:
        if not here(group, b):
            continue
        if b["sku"] == sku:
            how = "OWNED"
        elif reaches(b["sku"], sku, set()):
            how = {"bundle": "VIA_BUNDLE", "edition": "VIA_EDITION"}.get(catalog[b["sku"]]["kind"])
        else:
            how = None
        if how is None:
            continue
        why = list(hit.get(b["n"], []))
        if lock != "all" and b["region"] != lock:
            why.append("REGION_LOCK")
        if why:
            dead += why
        else:
            live.append(how)

    # sec 2. a subscription stays with the account that took it out and
    # pays no attention to region
    if item.get("in_sub_catalog") == "yes":
        for s in subs:
            if s["player"] != player:
                continue
            if day(s["start"]) <= asof <= day(s["end"]):
                live.append("VIA_SUB")
            elif day(s["end"]) < asof:
                dead.append("SUB_LAPSED")

    # sec 4. a buy of the title on or after the grant spends the key, and
    # a spent key is no path at all, refunded buy or not
    for g in txns:
        if g["kind"] != "promo_grant" or g["sku"] != sku or not here(group, g):
            continue
        used = 0
        for b in buys:
            if b["sku"] == sku and b["on"] >= g["on"] and here(group, b):
                used += 1
        if used:
            continue
        why = []
        if g["expires"] == "" or day(g["expires"]) < asof:
            why.append("PROMO_EXPIRED")
        if lock != "all" and g["region"] != lock:
            why.append("REGION_LOCK")
        if why:
            dead += why
        else:
            live.append("VIA_PROMO")

    if live:
        # sec 7. the base is only looked at once the expansion has a live
        # path of its own, and the chain stops a catalog loop
        base = item.get("requires") or ""
        if base:
            if base == sku or base in chain:
                return "no access", "NEEDS_BASE"
            if settle(player, base, chain + (sku,))[0] != "access":
                return "no access", "NEEDS_BASE"
        for code in GRANTS:
            if code in live:
                return "access", code
    for code in BLOCKS:
        if code in dead:
            return "no access", code
    return "no access", "NO_GRANT"


print("access decisions as of " + asof.isoformat())
counts = {}
yes = 0
for q in tickets:
    verdict, why = settle(q["player"], q["sku"])
    counts[why] = counts.get(why, 0) + 1
    if verdict == "access":
        yes += 1
    print("  ".join((q["ticket"], q["player"], q["sku"], verdict, why)))
for code in GRANTS + BLOCKS + ["NO_GRANT"]:
    if code in counts:
        print("%s: %d" % (code, counts[code]))
totals = "tickets=%d access=%d no_access=%d" % (len(tickets), yes, len(tickets) - yes)
print(totals)
print(totals, file=sys.stderr)
