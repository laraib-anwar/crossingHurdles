#!/usr/bin/env python3
#
# access_check.py  -  answers the player access tickets in queries.csv
#
#   python3 access_check.py catalog.csv transactions.csv subscriptions.csv queries.csv 2026-07-20
#
# Follows access_rules.txt. Rule numbers below are the ones in that file.
# Report goes to stdout, the totals line goes to stderr as well.

import csv
import sys
from datetime import date


GRANT_ORDER = ["OWNED", "VIA_BUNDLE", "VIA_EDITION", "VIA_SUB", "VIA_PROMO"]
BLOCK_ORDER = ["TRANSFER_LOOP", "NEEDS_BASE", "CHARGEBACK", "REFUNDED",
               "REGION_LOCK", "SUB_LAPSED", "PROMO_EXPIRED"]


def to_date(text):
    year, month, dd = text.strip().split("-")
    return date(int(year), int(month), int(dd))


def read_csv(path):
    with open(path, newline="") as handle:
        table = list(csv.DictReader(handle))
    for row in table:
        for key in row:
            row[key] = (row[key] or "").strip()
    return table


if len(sys.argv) != 6:
    sys.stderr.write("usage: access_check.py catalog.csv transactions.csv "
                     "subscriptions.csv queries.csv YYYY-MM-DD\n")
    sys.exit(1)

catalog_file, history_file, subs_file, queries_file = sys.argv[1:5]
as_of = to_date(sys.argv[5])

catalog = {}
for item in read_csv(catalog_file):
    catalog[item["sku_id"]] = item

# Anything dated after the as of date has not happened yet (rule 5), so it
# never makes it into the history at all. row_no keeps the export order,
# which the rules still use in two places.
history = []
row_no = 0
for row in read_csv(history_file):
    row["row_no"] = row_no
    row["when"] = to_date(row["date"])
    row_no += 1
    if row["when"] <= as_of:
        history.append(row)

subscriptions = read_csv(subs_file)
tickets = read_csv(queries_file)

purchases = []
for row in history:
    if row["kind"] == "purchase":
        purchases.append(row)

transfer_rows = []
for row in history:
    if row["kind"] == "transfer" or row["kind"] == "transfer_cancel":
        transfer_rows.append(row)
transfer_rows.sort(key=lambda r: (r["when"], r["row_no"]))


# ---- Rule 3, rings ----
# Who each account points at: its first transfer out, wiped again if the
# closure was cancelled. Then walk from every account; if the walk comes
# back to an account already on it, the accounts from that point on are
# the ring. Accounts that only lead into the ring are not part of it.
points_to = {}
for row in transfer_rows:
    account = row["player"]
    if row["kind"] == "transfer_cancel":
        if account in points_to:
            del points_to[account]
    elif account not in points_to:
        points_to[account] = row["sku"]

ring_accounts = set()
for first in points_to:
    path = [first]
    current = points_to[first]
    while current in points_to and current not in path:
        path.append(current)
        current = points_to[current]
    if current in path:
        for account in path[path.index(current):]:
            ring_accounts.add(account)


# ---- Rule 3, where each history sits ----
# open_ranges[a]: the stretches account a was open, as [from, to] with None
#   for open-ended. A closure ends the stretch on the transfer date and a
#   cancel starts a new one on the cancel date, so rows dated while the
#   account was closed belong to neither stretch.
# carrying[a]: whose rows account a is holding right now.
open_ranges = {}
carrying = {}


def note_account(account):
    if account and account not in open_ranges:
        open_ranges[account] = [[None, None]]
        carrying[account] = set([account])


for row in history:
    note_account(row["player"])
    if row["kind"] == "transfer":
        note_account(row["sku"])

closed = set()
for row in transfer_rows:
    account = row["player"]
    if row["kind"] == "transfer_cancel":
        if account not in closed:
            continue            # never left, nothing to call back
        # When a transfer gets cancelled, you only pull back the closed
        # account's own rows, while anything that tagged along stays right
        # where it landed.
        for other in carrying:
            if other != account:
                carrying[other].discard(account)
        carrying[account].add(account)
        open_ranges[account].append([row["when"], None])
        closed.discard(account)
        continue
    if account in closed or account in ring_accounts:
        continue                # already gone, or stuck in the ring
    open_ranges[account][-1][1] = row["when"]
    target = row["sku"]
    if target not in ring_accounts:
        carrying[target] = carrying[target] | carrying[account]
    # a history sent into a ring settles nowhere (rule 3)
    carrying[account] = set()
    closed.add(account)


def belongs(row, owners):
    """True if row is part of the history these owners hold today."""
    if row["player"] not in owners:
        return False
    for start, end in open_ranges.get(row["player"], [[None, None]]):
        after_start = start is None or row["when"] >= start
        before_end = end is None or row["when"] <= end
        if after_start and before_end:
            return True
    return False


def covers(pack, sku, seen):
    # bundles can hold bundles, and two of them name each other in the
    # catalog, so each pack is only opened once
    seen.add(pack)
    for part in catalog.get(pack, {}).get("covers", "").split("+"):
        part = part.strip()
        if not part:
            continue
        if part == sku:
            return True
        if part not in seen and covers(part, sku, seen):
            return True
    return False


def decide(player, sku, asked_on_the_way=()):
    if player in ring_accounts:
        return "no access", "TRANSFER_LOOP"

    owners = carrying.get(player, set([player]))
    item = catalog.get(sku, {})
    region_lock = item.get("region_lock") or "all"

    # For refunds and chargebacks, they always hit the most recent purchase
    # of that SKU on or before the refund date, and if two purchases fall on
    # the exact same day, you go with the one lower down in the file. The
    # only catch is that if a refund comes in after the account was already
    # closed, it stays linked to that closed account.
    kills = {}
    for event in history:
        if event["kind"] != "refund" and event["kind"] != "chargeback":
            continue
        if not belongs(event, owners):
            continue
        target = None
        for buy in purchases:
            if buy["player"] != event["player"] or buy["sku"] != event["sku"]:
                continue
            if buy["when"] > event["when"] or not belongs(buy, owners):
                continue
            if target is None or buy["when"] >= target["when"]:
                target = buy
        if target is not None:
            code = "CHARGEBACK" if event["kind"] == "chargeback" else "REFUNDED"
            kills.setdefault(target["row_no"], []).append(code)

    live = []
    dead = []

    for buy in purchases:
        if not belongs(buy, owners):
            continue
        if buy["sku"] == sku:
            route = "OWNED"
        elif catalog[buy["sku"]]["kind"] in ("bundle", "edition") and covers(buy["sku"], sku, set()):
            route = "VIA_" + catalog[buy["sku"]]["kind"].upper()
        else:
            continue
        reasons = list(kills.get(buy["row_no"], []))
        if region_lock != "all" and buy["region"] != region_lock:
            reasons.append("REGION_LOCK")
        if reasons:
            dead.extend(reasons)
        else:
            live.append(route)

    # subscriptions stay with the account that bought them and ignore
    # region locks
    if item.get("in_sub_catalog") == "yes":
        for span in subscriptions:
            if span["player"] != player:
                continue
            start, end = to_date(span["start"]), to_date(span["end"])
            if start <= as_of <= end:
                live.append("VIA_SUB")
            elif end < as_of:
                dead.append("SUB_LAPSED")

    for grant in history:
        if grant["kind"] != "promo_grant" or grant["sku"] != sku:
            continue
        if not belongs(grant, owners):
            continue
        # Lastly, promo keys are used up by any purchase of the same SKU on
        # or after the grant date, and even if that purchase gets refunded
        # later, the key is still burned for good.
        spent = False
        for buy in purchases:
            if buy["sku"] == sku and buy["when"] >= grant["when"] and belongs(buy, owners):
                spent = True
        if spent:
            continue
        reasons = []
        if not grant["expires"] or to_date(grant["expires"]) < as_of:
            reasons.append("PROMO_EXPIRED")
        if region_lock != "all" and grant["region"] != region_lock:
            reasons.append("REGION_LOCK")
        if reasons:
            dead.extend(reasons)
        else:
            live.append("VIA_PROMO")

    if live:
        # rule 7: an expansion needs its base to answer access too
        base = item.get("requires", "")
        if base:
            if base == sku or base in asked_on_the_way:
                return "no access", "NEEDS_BASE"
            if decide(player, base, asked_on_the_way + (sku,))[0] != "access":
                return "no access", "NEEDS_BASE"
        for code in GRANT_ORDER:
            if code in live:
                return "access", code

    for code in BLOCK_ORDER:
        if code in dead:
            return "no access", code
    return "no access", "NO_GRANT"


count_by_reason = {}
granted = 0
print("access decisions as of " + as_of.isoformat())
for ticket in tickets:
    answer, reason = decide(ticket["player"], ticket["sku"])
    count_by_reason[reason] = count_by_reason.get(reason, 0) + 1
    if answer == "access":
        granted += 1
    print("  ".join([ticket["ticket"], ticket["player"], ticket["sku"], answer, reason]))

for code in GRANT_ORDER + BLOCK_ORDER + ["NO_GRANT"]:
    if code in count_by_reason:
        print("%s: %d" % (code, count_by_reason[code]))

totals = "tickets=%d access=%d no_access=%d" % (len(tickets), granted, len(tickets) - granted)
print(totals)
sys.stderr.write(totals + "\n")
