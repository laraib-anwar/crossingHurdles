# Support access checker, see access_rules.txt for the policy itself.
#
# usage:
#   python3 access_check.py catalog.csv transactions.csv subscriptions.csv queries.csv 2026-07-20
#
# stdout gets the full report, stderr gets the totals line again so the
# cron mail shows it.

import csv
import sys
from datetime import date


def parse_date(text):
    year, month, day = text.strip().split("-")
    return date(int(year), int(month), int(day))


def load_csv(path):
    rows = []
    with open(path, newline="") as f:
        for row in csv.DictReader(f):
            clean = {}
            for key, value in row.items():
                if value is None:
                    value = ""
                clean[key] = value.strip()
            rows.append(clean)
    return rows


if len(sys.argv) != 6:
    print("usage: access_check.py catalog.csv transactions.csv subscriptions.csv queries.csv YYYY-MM-DD", file=sys.stderr)
    sys.exit(1)

as_of = parse_date(sys.argv[5])

catalog = {}
for row in load_csv(sys.argv[1]):
    catalog[row["sku_id"]] = row

# Keep the file position on every row. Same day transfers and same day
# repurchases both fall back on it.
history = []
row_no = 0
for row in load_csv(sys.argv[2]):
    row["row_no"] = row_no
    row["when"] = parse_date(row["date"])
    row_no += 1
    if row["when"] > as_of:
        continue  # hasn't happened yet as of the run date
    history.append(row)

subscriptions = load_csv(sys.argv[3])
tickets = load_csv(sys.argv[4])

purchases = []
moves = []
for row in history:
    if row["kind"] == "purchase":
        purchases.append(row)
    if row["kind"] == "transfer" or row["kind"] == "transfer_cancel":
        moves.append(row)
moves.sort(key=lambda row: (row["when"], row["row_no"]))


# ---- section 3, rings ----
# An account only moves out once, so its first transfer is the edge that
# counts. A cancel takes the edge away and the next transfer it files
# becomes the edge instead. Date order of the edges doesn't matter for a
# ring, only whether they close a loop by the as of date.
moves_to = {}
for row in moves:
    account = row["player"]
    if row["kind"] == "transfer_cancel":
        if account in moves_to:
            del moves_to[account]
    elif account not in moves_to:
        moves_to[account] = row["sku"]

ring = set()
for start in moves_to:
    path = [start]
    nxt = moves_to[start]
    while nxt in moves_to and nxt not in path:
        path.append(nxt)
        nxt = moves_to[nxt]
    if nxt in path:
        # only the loop itself, not the accounts that lead into it
        loop_from = path.index(nxt)
        for account in path[loop_from:]:
            ring.add(account)


# ---- section 3, where each history sits ----
# open_spans[acct] is a list of [opened, closed] date pairs. An account's
# own rows only count if they fall inside one of its spans, so anything
# dated while it was closed is never recalled by a cancel.
# holding[acct] is the set of accounts whose rows currently sit with acct.
open_spans = {}
holding = {}
closed = set()

for row in history:
    names = [row["player"]]
    if row["kind"] == "transfer":
        names.append(row["sku"])
    for name in names:
        if name not in open_spans:
            open_spans[name] = [[None, None]]
            holding[name] = {name}

for row in moves:
    account = row["player"]
    day = row["when"]

    if row["kind"] == "transfer_cancel":
        if account not in closed:
            continue  # never moved out, nothing to cancel
        # pull this account's own rows back from wherever they ended up,
        # everything that travelled with them stays put
        for other in holding:
            if other != account:
                holding[other].discard(account)
        holding[account].add(account)
        open_spans[account].append([day, None])
        closed.remove(account)
        continue

    if account in closed or account in ring:
        continue

    open_spans[account][-1][1] = day
    target = row["sku"]
    if target not in ring:
        holding[target] = holding[target] | holding[account]
    # handed into a ring = settles nowhere, sender still ends up empty
    holding[account] = set()
    closed.add(account)


def belongs(held_accounts, row):
    """True if this row sits with the account holding held_accounts."""
    owner = row["player"]
    if owner not in held_accounts:
        return False
    for opened, shut in open_spans.get(owner, [[None, None]]):
        if opened is not None and row["when"] < opened:
            continue
        if shut is not None and row["when"] > shut:
            continue
        return True
    return False


def pack_reaches(pack, wanted, visited):
    # bundles can cover other bundles, and two in the catalog cover each
    # other, so each pack is only opened once
    visited.add(pack)
    covers = catalog.get(pack, {}).get("covers", "")
    for part in covers.split("+"):
        part = part.strip()
        if part == "":
            continue
        if part == wanted:
            return True
        if part not in visited and pack_reaches(part, wanted, visited):
            return True
    return False


# strongest first, section 8
GRANT_ORDER = ["OWNED", "VIA_BUNDLE", "VIA_EDITION", "VIA_SUB", "VIA_PROMO"]
BLOCK_ORDER = ["TRANSFER_LOOP", "NEEDS_BASE", "CHARGEBACK", "REFUNDED",
               "REGION_LOCK", "SUB_LAPSED", "PROMO_EXPIRED"]


def decide(player, sku, chain=()):
    if player in ring:
        return "no access", "TRANSFER_LOOP"

    held = holding.get(player, {player})
    item = catalog.get(sku, {})
    region = item.get("region_lock") or "all"

    # Section 4. A refund or chargeback lands on the latest purchase of
    # that sku on or before its own date. If two purchases share that
    # date, the one listed last in the file takes it.
    kills = {}
    for event in history:
        if event["kind"] != "refund" and event["kind"] != "chargeback":
            continue
        if not belongs(held, event):
            continue
        candidates = []
        for p in purchases:
            if p["player"] == event["player"] and p["sku"] == event["sku"] \
                    and p["when"] <= event["when"] and belongs(held, p):
                candidates.append(p)
        if not candidates:
            continue
        latest = max(p["when"] for p in candidates)
        victim = None
        for p in candidates:
            if p["when"] == latest:
                victim = p
        if event["kind"] == "chargeback":
            reason = "CHARGEBACK"
        else:
            reason = "REFUNDED"
        kills.setdefault(victim["row_no"], []).append(reason)

    grants = []
    blocks = []

    for p in purchases:
        if not belongs(held, p):
            continue
        if p["sku"] == sku:
            route = "OWNED"
        elif pack_reaches(p["sku"], sku, set()):
            kind = catalog[p["sku"]]["kind"]
            if kind == "bundle":
                route = "VIA_BUNDLE"
            elif kind == "edition":
                route = "VIA_EDITION"
            else:
                route = None
        else:
            route = None
        if route is None:
            continue
        problems = list(kills.get(p["row_no"], []))
        if region != "all" and p["region"] != region:
            problems.append("REGION_LOCK")
        if problems:
            blocks.extend(problems)
        else:
            grants.append(route)

    # subscriptions stay with the account that bought them and ignore region
    if item.get("in_sub_catalog") == "yes":
        for sub in subscriptions:
            if sub["player"] != player:
                continue
            start = parse_date(sub["start"])
            end = parse_date(sub["end"])
            if start <= as_of <= end:
                grants.append("VIA_SUB")
            elif end < as_of:
                blocks.append("SUB_LAPSED")

    for key in history:
        if key["kind"] != "promo_grant" or key["sku"] != sku:
            continue
        if not belongs(held, key):
            continue
        # a purchase of the title on or after the grant spends the key,
        # and a spent key isn't a path at all, refunded purchase or not
        spent = False
        for p in purchases:
            if p["sku"] == sku and p["when"] >= key["when"] and belongs(held, p):
                spent = True
                break
        if spent:
            continue
        problems = []
        if key["expires"] == "" or parse_date(key["expires"]) < as_of:
            problems.append("PROMO_EXPIRED")
        if region != "all" and key["region"] != region:
            problems.append("REGION_LOCK")
        if problems:
            blocks.extend(problems)
        else:
            grants.append("VIA_PROMO")

    if grants:
        # Section 7. Only look at the base once the expansion itself has a
        # live path, and carry the chain along so a catalog loop stops.
        base = item.get("requires") or ""
        if base:
            if base == sku or base in chain:
                return "no access", "NEEDS_BASE"
            verdict, _ = decide(player, base, chain + (sku,))
            if verdict != "access":
                return "no access", "NEEDS_BASE"
        for code in GRANT_ORDER:
            if code in grants:
                return "access", code

    if blocks:
        for code in BLOCK_ORDER:
            if code in blocks:
                return "no access", code

    return "no access", "NO_GRANT"


out = ["access decisions as of " + as_of.isoformat()]
counts = {}
with_access = 0
for t in tickets:
    verdict, reason = decide(t["player"], t["sku"])
    counts[reason] = counts.get(reason, 0) + 1
    if verdict == "access":
        with_access += 1
    out.append("  ".join([t["ticket"], t["player"], t["sku"], verdict, reason]))

for code in GRANT_ORDER + BLOCK_ORDER + ["NO_GRANT"]:
    if code in counts:
        out.append("%s: %d" % (code, counts[code]))

totals = "tickets=%d access=%d no_access=%d" % (len(tickets), with_access, len(tickets) - with_access)
out.append(totals)
print("\n".join(out))
print(totals, file=sys.stderr)
