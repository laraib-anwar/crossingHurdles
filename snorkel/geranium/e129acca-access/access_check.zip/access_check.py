import sys, csv
from datetime import date

# support access answers. usage:
# access_check.py catalog.csv transactions.csv subscriptions.csv queries.csv 2026-07-20
# section numbers in the comments are access_rules.txt

args = sys.argv[1:]
if len(args) != 5:
    print("usage: access_check.py catalog.csv transactions.csv subscriptions.csv queries.csv yyyy-mm-dd", file=sys.stderr)
    sys.exit(1)


def day(text):
    y, m, d = text.strip().split("-")
    return date(int(y), int(m), int(d))


def rows(path):
    with open(path, newline="") as fp:
        out = list(csv.DictReader(fp))
    for row in out:
        for k in row:
            row[k] = (row[k] or "").strip()
    return out


as_of = day(args[4])
catalog = {}
for row in rows(args[0]):
    catalog[row["sku_id"]] = row

events = []
for pos, row in enumerate(rows(args[1])):
    row["pos"] = pos
    row["on"] = day(row["date"])
    if row["on"] <= as_of:
        events.append(row)
subs = rows(args[2])
tickets = rows(args[3])

buys = [e for e in events if e["kind"] == "purchase"]
moves = [e for e in events if e["kind"] in ("transfer", "transfer_cancel")]
moves.sort(key=lambda e: (e["on"], e["pos"]))

# sec 3. an account's edge is its first transfer out, until a cancel
edge = {}
for e in moves:
    acct = e["player"]
    if e["kind"] == "transfer_cancel":
        edge.pop(acct, None)
    elif acct not in edge:
        edge[acct] = e["sku"]

ring = set()
for start in edge:
    walk = [start]
    at = edge[start]
    while at in edge and at not in walk:
        walk.append(at)
        at = edge[at]
    if at in walk:
        ring.update(walk[walk.index(at):])

# spans[a] = the [opened, closed] stretches a was open for
# holds[a] = accounts whose rows are sitting with a
spans = {}
holds = {}
for e in events:
    for acct in (e["player"], e["sku"] if e["kind"] == "transfer" else None):
        if acct and acct not in spans:
            spans[acct] = [[None, None]]
            holds[acct] = {acct}

gone = set()
for e in moves:
    acct = e["player"]
    if e["kind"] == "transfer_cancel":
        if acct in gone:
            for other in holds:
                if other != acct:
                    holds[other].discard(acct)
            holds[acct].add(acct)
            spans[acct].append([e["on"], None])
            gone.discard(acct)
    elif acct not in gone and acct not in ring:
        spans[acct][-1][1] = e["on"]
        if e["sku"] not in ring:
            holds[e["sku"]] = holds[e["sku"]] | holds[acct]
        holds[acct] = set()
        gone.add(acct)


def counts(held, e):
    if e["player"] not in held:
        return False
    for lo, hi in spans.get(e["player"], [[None, None]]):
        if (lo is None or e["on"] >= lo) and (hi is None or e["on"] <= hi):
            return True
    return False


def reaches(pack, want, opened):
    opened.add(pack)
    for part in catalog.get(pack, {}).get("covers", "").split("+"):
        part = part.strip()
        if part == want:
            return True
        if part and part not in opened and reaches(part, want, opened):
            return True
    return False


GRANTS = ("OWNED", "VIA_BUNDLE", "VIA_EDITION", "VIA_SUB", "VIA_PROMO")
BLOCKS = ("TRANSFER_LOOP", "NEEDS_BASE", "CHARGEBACK", "REFUNDED", "REGION_LOCK", "SUB_LAPSED", "PROMO_EXPIRED")


def settle(player, sku, chain=()):
    if player in ring:
        return "no access", "TRANSFER_LOOP"
    held = holds.get(player, {player})
    title = catalog.get(sku, {})
    lock = title.get("region_lock") or "all"

    # sec 4. a refund or chargeback hits the latest buy of the sku on or
    # before it, the lower row if two share that date
    killed = {}
    for e in events:
        if e["kind"] not in ("refund", "chargeback") or not counts(held, e):
            continue
        hit = None
        for b in buys:
            if b["player"] == e["player"] and b["sku"] == e["sku"] and b["on"] <= e["on"] and counts(held, b):
                if hit is None or b["on"] >= hit["on"]:
                    hit = b
        if hit:
            killed.setdefault(hit["pos"], []).append("CHARGEBACK" if e["kind"] == "chargeback" else "REFUNDED")

    live, dead = [], []
    for b in buys:
        if not counts(held, b):
            continue
        if b["sku"] == sku:
            how = "OWNED"
        elif reaches(b["sku"], sku, set()) and catalog[b["sku"]]["kind"] in ("bundle", "edition"):
            how = "VIA_" + catalog[b["sku"]]["kind"].upper()
        else:
            continue
        why = killed.get(b["pos"], []) + (["REGION_LOCK"] if lock != "all" and b["region"] != lock else [])
        if why:
            dead += why
        else:
            live.append(how)

    if title.get("in_sub_catalog") == "yes":
        for s in subs:
            if s["player"] != player:
                continue
            if day(s["start"]) <= as_of <= day(s["end"]):
                live.append("VIA_SUB")
            elif day(s["end"]) < as_of:
                dead.append("SUB_LAPSED")

    for g in events:
        if g["kind"] != "promo_grant" or g["sku"] != sku or not counts(held, g):
            continue
        # a later buy of the same title uses the key up
        if any(b["sku"] == sku and b["on"] >= g["on"] and counts(held, b) for b in buys):
            continue
        why = []
        if not g["expires"] or day(g["expires"]) < as_of:
            why.append("PROMO_EXPIRED")
        if lock != "all" and g["region"] != lock:
            why.append("REGION_LOCK")
        if why:
            dead += why
        else:
            live.append("VIA_PROMO")

    if live:
        base = title.get("requires", "")
        if base and (base == sku or base in chain or settle(player, base, chain + (sku,))[0] != "access"):
            return "no access", "NEEDS_BASE"
        return "access", [c for c in GRANTS if c in live][0]
    for c in BLOCKS:
        if c in dead:
            return "no access", c
    return "no access", "NO_GRANT"


tally = {}
yes = 0
print("access decisions as of %s" % as_of.isoformat())
for t in tickets:
    verdict, reason = settle(t["player"], t["sku"])
    tally[reason] = tally.get(reason, 0) + 1
    if verdict == "access":
        yes += 1
    print("  ".join((t["ticket"], t["player"], t["sku"], verdict, reason)))
for c in GRANTS + BLOCKS + ("NO_GRANT",):
    if c in tally:
        print("%s: %d" % (c, tally[c]))
totals = "tickets=%d access=%d no_access=%d" % (len(tickets), yes, len(tickets) - yes)
print(totals)
print(totals, file=sys.stderr)
