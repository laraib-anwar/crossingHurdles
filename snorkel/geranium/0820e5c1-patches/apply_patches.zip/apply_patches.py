#!/usr/bin/env python3
#
# apply_patches.py - run the patch queue against the collector baseline
#
#   python3 apply_patches.py base_config.txt patches.csv > patch_report.txt
#
# rules are in patch_rules.txt, dont change behaviour here without
# changing that file first (change board sign off)

import sys
import csv

if len(sys.argv) != 3:
    sys.exit("usage: apply_patches.py base_config.txt patches.csv")

f = open(sys.argv[1])
lines = f.read().split("\n")
f.close()
while len(lines) > 0 and lines[-1] == "":
    lines.pop()

f = open(sys.argv[2], newline="")
queue = list(csv.DictReader(f))
f.close()
for p in queue:
    p["patch_id"] = p["patch_id"].strip()
    p["action"] = p["action"].strip()
    p["at_line"] = int(p["at_line"])
    p["anchor"] = p["anchor"].strip()
    if p.get("group") == None:
        p["group"] = ""
    p["group"] = p["group"].strip()

locked = set()      # line numbers written this run
out = []            # one [id, status, detail] per patch
done_grps = []
curgrp = ""
grp_start = 0
saved_lines = None
saved_locked = None


def rollback_check():
    global lines, locked
    failed = False
    for row in out[grp_start:]:
        if row[1] == "rejected":
            failed = True
    if failed == True:
        for row in out[grp_start:]:
            row[1] = "rejected"
            row[2] = "group " + curgrp + " rolled back"
        lines = saved_lines
        locked = saved_locked
    done_grps.append(curgrp)


for idx in range(0, len(queue)):
    p = queue[idx]
    rec = p["at_line"]

    if p["group"] != curgrp:
        if curgrp != "":
            rollback_check()
        if p["group"] in done_grps:
            sys.exit("group " + p["group"] + " turns up in two separate stretches of the queue, stopping")
        curgrp = p["group"]
        grp_start = len(out)
        saved_lines = list(lines)
        saved_locked = set(locked)

    # look on the recorded line, then 1 above, 1 below, 2 above ... out to 4
    hit = None
    for dist in range(0, 5):
        if dist == 0:
            cands = [rec]
        else:
            cands = [rec - dist, rec + dist]
        for c in cands:
            if c >= 1 and c <= len(lines):
                if lines[c - 1].strip() == p["anchor"]:
                    hit = c
                    break
        if hit != None:
            break

    if hit == None:
        out.append([p["patch_id"], "rejected", "anchor not found near line " + str(rec)])
        continue
    if hit in locked:
        out.append([p["patch_id"], "rejected", "line " + str(hit) + " already written by an earlier patch"])
        continue

    if p["action"] == "insert_after":
        new_lines = p["payload"].split("|")
        # board rule: if 2+ later patches were recorded on the lines this
        # would add (counted below where the anchor really is) skip it
        waiting = 0
        for later in queue[idx + 1:]:
            if later["at_line"] > hit and later["at_line"] <= hit + len(new_lines):
                waiting = waiting + 1
        if waiting >= 2:
            out.append([p["patch_id"], "rejected", "passed over, " + str(waiting) + " later patches were written against the lines it adds"])
            continue
        lines = lines[:hit] + new_lines + lines[hit:]
        delta = len(new_lines)
        mine = set()
        for n in range(hit, hit + delta + 1):
            mine.add(n)
    elif p["action"] == "delete":
        lines = lines[:hit - 1] + lines[hit:]
        delta = -1
        mine = set()
    else:
        lines[hit - 1] = p["payload"]
        delta = 0
        mine = set([hit])

    relocked = set()
    for n in locked:
        if n > hit:
            relocked.add(n + delta)
        else:
            relocked.add(n)
    locked = relocked.union(mine)

    if hit == rec:
        out.append([p["patch_id"], "applied", "at line " + str(hit)])
    else:
        out.append([p["patch_id"], "applied", "at line %d, %+d from the recorded line" % (hit, hit - rec)])

if curgrp != "":
    rollback_check()

applied = 0
shifted = 0
for row in out:
    if row[1] == "applied":
        applied += 1
        if row[2].endswith("from the recorded line"):
            shifted += 1
rejected = len(out) - applied

print("patch run against base_config.txt")
print("patches %d, applied %d, of those shifted %d, rejected %d" % (len(queue), applied, shifted, rejected))
print("")
for row in out:
    print("  " + row[0] + "  " + row[1].ljust(8) + " " + row[2])
print("")
print("resulting config, " + str(len(lines)) + " lines")
n = 1
for l in lines:
    print(str(n).rjust(4) + "  " + l)
    n += 1

sys.stderr.write("patches=" + str(len(queue)) + " applied=" + str(applied) + " shifted=" + str(shifted)
                 + " rejected=" + str(rejected) + " lines=" + str(len(lines)) + "\n")
