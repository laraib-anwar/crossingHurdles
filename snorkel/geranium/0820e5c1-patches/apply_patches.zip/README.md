# apply_patches

Runs the change control queue against a collector baseline, per
patch_rules.txt. Run:

    python3 apply_patches.py base_config.txt patches.csv

The report prints to stdout and one summary line goes to stderr as
patches=N applied=N shifted=N rejected=N lines=N. The committed
patch_report.txt is this queue against the current baseline, a short
note on what happened followed by the per patch verdicts and the
resulting config in full.

Most tools get drift wrong, so it is the thing to get right.
Every patch that changes the length of the file moves the lines
below it, so a later patch's recorded line can stop matching where
its anchor actually sits, and now and then starts matching. In this queue the second patch inserts two lines
near the top, and from that point on eight of the patches that go in
find their anchor one to four lines away from where the author
wrote it down. Match every anchor against the baseline instead of the
running file and this queue starts refusing edits that are perfectly
good, because the recorded numbers stopped describing that file the
moment the second patch went in.

The drift is not always in the direction you expect. One patch in this
queue records a line that is wrong for the baseline and becomes right
only after the insert above it lands, so it applies cleanly at the
recorded number, where against the original file its anchor sat two
lines higher. Two different patches in the queue record the same line number
for two different settings, which is what a queue looks like when it
has been maintained by hand across several weeks.

Held lines are the other half of the job. Once a patch has written a
line, that line belongs to it for the rest of the run, unless the patch
comes out again with a group that rolled back, and a later patch whose
anchor lands there is rejected rather than applied on top. Those held
positions move with the file as later inserts and deletes shift them,
so tracking them as fixed line numbers will let a genuine conflict
through once anything above them changes length. The queue here runs
into three of those collisions and every one of them is deliberate.

The search window is four lines either side, checked nearest first,
which means an anchor that has drifted five lines is reported as not
found rather than matched to something further away. That is the
conservative choice and it is the intended one. A patch on its own that
cannot find its anchor changes nothing at all, and it also shifts nothing, so
the patches after it are unaffected by the rejection. A patch inside a
group is the exception, and that is the part worth reading twice.

Groups land whole or not at all. If one member is refused, the file
goes back to how it stood before the first member was tried and every
member is reported as rolled back, including the ones already written.
The lines those patches were holding are released with them, which is
where a tool that skips the rollback goes wrong quietly rather than
loudly: the last patch in this queue wants a line that a rolled back
insert had been holding, and it goes in cleanly with no shift. Skip
the rollback and that patch comes back as a conflict instead, so the
run reports one fewer applied patch while the config it writes keeps
the same length, because the insert it collided with supplied that
line already. The count moves and the length does not, which is
what makes this one easy to miss. Buffer the group, decide it as a unit,
and put both the file and the held lines back if it fails. A group's
rows sit together in the queue, so the unit to buffer is one stretch of
rows rather than every row carrying that name wherever it turns up. If
a queue ever splits a group across two places the tool stops, because
there is no honest answer to how far back the rollback should reach.

Look ahead trips people up. An insert holds what it adds, and one
insert here, p-121, would add exactly the two lines that p-122 and
p-123 were recorded against, 21 and 22. Two later patches recorded
against an insert's new lines is the trigger, so the rules pass p-121
over and both of the others go in. Skip the look ahead and p-121 lands,
p-122 and p-123 still apply two lines lower, and the run reports 16
applied and a 49 line config with the two spool lines in it. The lines an insert would add are the ones just below
where its anchor is found, not below the line it recorded. p-112 is
the case that shows the difference: it records line 43, its anchor has
drifted to 45, so its one new line would be 46, and no later patch
recorded 46. It applies at 45 with a shift of +2. Measure from the
recorded line instead and it looks like it would take line 44, which
p-125 and p-128 both recorded, and it gets passed over for nothing.
Count what is still to come by the line each patch recorded, and count
only the lines the insert would add, not the anchor under it. That
last point is about this look ahead alone and says nothing about what
the insert holds once it goes in. If it does go in it holds its anchor
too, as the next section sets out, so the two counts are deliberately
different: the look ahead asks how many later patches the insert's new
lines would block, while the held set is what refuses them afterwards.
Do the look ahead before the insert goes in rather than trying to
unpick it later.

If you change the queue or the baseline, rerun and diff against the
committed report before trusting anything. The per patch verdicts move
before the resulting config visibly does, and a shift reported as zero
when it should be plus two is the earliest sign that drift tracking
has come apart.

Held lines are the part worth understanding before you change
anything. A patch does not only claim the line it edits. A replace
holds the line it rewrote. An insert holds the lines it added and
also the anchor line it was positioned against, because the anchor is
what gave the insert its position, and letting a later patch rewrite
that anchor would change what the earlier insert meant without anyone
saying so. A delete holds nothing, since the line it was about is
gone. Any later patch whose search lands on a held line is refused as
a conflict rather than applied, and the report says which line and
why.

A patch that drifted and a patch that is lost are not the same thing.
Anchors are searched
four lines either side of the recorded number, so a patch whose line moved
by four still goes in and the report notes the shift. A patch whose
line moved by five is refused with anchor not found, and so is a
patch whose anchor text is not in that window of the running file at
all. Those two, the line that moved too far and the anchor that is not
there, share one wording in the report, anchor not found near the
recorded line, and that is deliberate: from the tool's side they are
the same situation, a recorded anchor that cannot be located, and the
author has to look at the file to see which one they are in.

A patch refused on its own leaves the file exactly as it was, so it
shifts nothing for the patches that follow. A group member is the
exception: it may already have been written before the refusal came,
and the rollback that takes it back out is what decides several of the
verdicts below it. That matters when reading the shift numbers, with
one more qualification. Only a patch that changes the file's line
count moves anything below it, so refusing a run of replaces changes
no drift at all, while refusing a run of inserts or deletes near the
top does leave smaller drifts below than the same queue would show if
those patches had gone in.

