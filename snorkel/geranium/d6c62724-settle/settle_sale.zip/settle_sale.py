#!/usr/bin/env python3
#
# settle_sale.py - settle the evening sale per auction_rules.txt
#
#   python3 settle_sale.py lots.csv bidders.csv bids.csv > settlement_sheet.txt
#
# lots settle in the order they actually closed, extensions included,
# and a bidder's limit goes down as they win things

import sys
import csv
from datetime import datetime, timedelta

if len(sys.argv) != 4:
    sys.exit("need lots.csv bidders.csv bids.csv")


def readcsv(path):
    f = open(path, newline="")
    rows = list(csv.DictReader(f))
    f.close()
    return rows


def ts(s):
    return datetime.strptime(s.strip(), "%Y-%m-%d %H:%M:%S")


def increment(amount):
    # bid step off the second highest max (section 2 table)
    if amount < 10000:
        return 500
    if amount < 50000:
        return 2500
    if amount < 200000:
        return 10000
    return 25000


lots = readcsv(sys.argv[1])
bidders = readcsv(sys.argv[2])
bids = readcsv(sys.argv[3])

closes = {}
open_at = {}
res = {}
maxes = {}
for L in lots:
    lot = L["lot_id"].strip()
    closes[lot] = ts(L["scheduled_close"])
    open_at[lot] = int(L["open_cents"])
    res[lot] = int(L["reserve_cents"])
    maxes[lot] = []

# a bid that counts in the last two minutes moves the close to 3 min after it
ext = []
for b in bids:
    lot = b["lot_id"].strip()
    t = ts(b["bid_time"])
    m = int(b["max_cents"])
    if t >= closes[lot] or m <= open_at[lot]:
        continue
    maxes[lot].append([b["bidder"].strip(), m])
    if (closes[lot] - t).total_seconds() <= 120:
        closes[lot] = t + timedelta(seconds=180)
        if lot not in ext:
            ext.append(lot)

budget = {}
roster = []
for b in bidders:
    bid_id = b["bidder_id"].strip()
    roster.append(bid_id)
    budget[bid_id] = int(b["limit_cents"])

spent = {}
n_sold = 0
n_passed = 0
total = 0
out = []

order = list(closes.keys())
order.sort(key=lambda lot: (closes[lot], lot))
for lot in order:
    head = "  " + lot.ljust(7) + " closed " + closes[lot].strftime("%H:%M:%S") + "  "

    usable = []
    for who, m in maxes[lot]:
        c = m
        if budget[who] < c:
            c = budget[who]
        if c > open_at[lot]:
            usable.append([who, c])

    if len(usable) == 0:
        n_passed += 1
        out.append(head + "passed, best usable 0 under reserve")
        continue

    top = 0
    for j in range(1, len(usable)):
        if usable[j][1] > usable[top][1]:
            top = j            # earliest bid keeps a tie at the top
    winner = usable[top][0]
    best = usable[top][1]
    others = []
    for j in range(len(usable)):
        if j != top:
            others.append(usable[j][1])
    others.sort()

    if best < res[lot]:
        n_passed += 1
        out.append(head + "passed, best usable " + str(best) + " under reserve")
        continue

    if len(others) == 0:
        price = open_at[lot]
    elif others[-1] == best:
        price = best
    else:
        price = others[-1] + increment(others[-1])
        if price > best:
            price = best
    if price < res[lot]:
        price = res[lot]    # reserve met, so the hammer never lands under it

    n_sold += 1
    total += price
    budget[winner] -= price
    spent[winner] = spent.get(winner, 0) + price
    out.append(head + "to " + winner.ljust(12) + " at " + str(price))

print("settlement sheet for the sale in " + sys.argv[1].split("/")[-1])
print("lots %d, sold %d, passed %d, gross %d" % (len(lots), n_sold, n_passed, total))
for l in out:
    print(l)
for who in roster:
    if who in spent:
        print("  %-12s spent %8d, limit left %8d" % (who, spent[who], budget[who]))

sys.stderr.write("lots=" + str(len(lots)) + " sold=" + str(n_sold) + " passed=" + str(n_passed)
                 + " gross=" + str(total) + " extended=" + str(len(ext)) + "\n")
