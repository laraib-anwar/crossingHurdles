# settle_sale

Settles one timed online sale against auction_rules.txt and produces
the settlement sheet. Run:

    python3 settle_sale.py lots.csv bidders.csv bids.csv

The sheet goes to stdout and one line goes to stderr:

    lots=18 sold=15 passed=3 gross=1753704 extended=2

settlement_sheet.txt is that run, a short note first and then the
sheet in full: every lot in the order it settled, then what each
winning bidder spent and has left.

What to watch for. The close times move before anything settles. A
bid that counts inside the final two minutes pushes that lot's close
three minutes past the bid, as many times as it happens, and a bid at
or after the current close is void. Two lots in this sale extend, and
one of them, lot-103, is won by a bid that would be void against the
catalogue time. Settle in catalogue order and the sheet comes out in
the wrong sequence. Hold lot-103 to its catalogue close and the lot
goes to the wrong bidder.

Budgets bite at settlement, not at bidding. A bidder's usable maximum
on a lot is the smaller of what they authorised and what remains of
their limit when that lot settles, and the hammer price comes off
their limit before the next lot is touched. Lot-115 here goes to the
third highest bidder on authorised money, and the two above them are
stopped for different reasons. The top one authorised 450957 but had
already spent 109297 earlier in the sale, leaving 410703 of a 520000
limit, which is less than the 420000 the third could still spend. The
second authorised 450616 against a registered limit of only 380000 and
had spent nothing at all, so its usable maximum was never more than
that limit. Price everything off authorised maximums and that lot pays
the wrong person.

Prices come from the proxy rule: one increment over the second best
usable maximum, capped at the leader's own, off the increment band of
the second best. Equal maximums go to the earlier bid at that
maximum. A lot whose best usable maximum is under reserve passes and
no money moves. A lot that meets its reserve never sells under it, so
lot-109, where the bidding reaches only 88974, goes at its 110000
reserve.

Two lots by hand, as a check on the tool. Lot-103 is scheduled for
18:04:00. b_pemberton's 150000 at 18:02:50 lands with 70 seconds left
and moves the close to 18:05:50, then b_lindqvist's 165000 at 18:05:35
lands with 15 seconds left and moves it to 18:08:35. It settles after
lot-105. The usable maximums are b_lindqvist 165000, b_maren 155877
(247503 left after lot-101), b_pemberton 150000, b_ash 139731 and
b_donovan 85050. The second best is 155877, the increment in that band
is 10000, and 165877 is over the leader's 165000, so b_lindqvist pays
165000, which clears the 140000 reserve.
Lot-115 is scheduled for 18:28:00 and bids at 18:27:20 and 18:29:40
move it to 18:32:40, so it settles last but one. b_ash is capped at its
380000 limit. b_donovan has spent 19342 on lot-108 and 89955 on
lot-113, so only 410703 of its 520000 is usable. b_pemberton has spent
687764 by then and still has 812236, so its 420000 stands. Leader
b_pemberton at 420000, second b_donovan at 410703, increment 25000,
and 435703 caps at 420000. Both match the sheet.

If you change any of the three files, rerun and diff against the
committed sheet before invoicing anything. Winners move before the
gross visibly does.
