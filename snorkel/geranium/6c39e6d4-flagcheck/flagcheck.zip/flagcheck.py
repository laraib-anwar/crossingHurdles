#   python3 flagcheck.py flags.csv rules.csv users.csv checks.csv > flag_answers.txt

import csv
import sys
from datetime import date, timedelta

if len(sys.argv) != 5:
    sys.exit("usage: flagcheck.py flags.csv rules.csv users.csv checks.csv")


def rd(path):
    with open(path, newline="") as fh:
        return [dict((k.strip(), (v or "").strip()) for k, v in r.items()) for r in csv.DictReader(fh)]


def ymd(s):
    # real YYYY-MM-DD only, else the row never takes effect
    p = s.split("-")
    if [len(x) for x in p] != [4, 2, 2] or not "".join(p).isdigit():
        return None
    try:
        return date(int(p[0]), int(p[1]), int(p[2]))
    except ValueError:
        return None


reg = {}
for n, r in enumerate(rd(sys.argv[1])):
    reg.setdefault(r["flag"].lower(), []).append((ymd(r["effective"]), n, r))
for f in reg:
    reg[f] = sorted([x for x in reg[f] if x[0]], key=lambda x: x[:2])


def live(f, d):
    return [x[2] for x in reg.get(f, []) if x[0] <= d]


def ok(r):
    return (r["status"].lower() in ("active", "kill") and r["fallback"].lower() in ("yes", "no")
            and (r["seats"] == "" or r["seats"].isdigit()))


def row(f, d):
    good = [r for r in live(f, d) if ok(r)]
    return good[-1] if good else None


rules = {}
bad_rules = 0
for r in rd(sys.argv[2]):
    f = r["flag"].lower()
    if (r["attribute"].lower() in ("plan", "region", "role", "beta") and r["op"].lower() in ("is", "is_not")
            and r["verdict"].lower() in ("yes", "no")):
        rules.setdefault(f, []).append(r)
    elif f in reg:
        bad_rules += 1

prof = {}
bad_prof = 0
for n, r in enumerate(rd(sys.argv[3])):
    d = ymd(r["changed"])
    if d is None:
        bad_prof += 1
        continue
    u = r["user_id"].lower()
    if u not in prof:
        prof[u] = []
    prof[u].append((d, n, r))
since = {}
for u in prof:
    prof[u].sort(key=lambda x: x[:2])
    since[u] = prof[u][0][0]


def as_of(u, d):
    p = None
    for x in prof[u]:
        if x[0] <= d:
            p = x[2]
    return p


held = {}


def line(d):
    # the enrolment line on d: earliest enrolment first, a same-day tie to
    # the user whose earliest readable row sits higher in users.csv
    return sorted([u for u in prof if since[u] <= d], key=lambda u: (since[u], prof[u][0][1]))


def holders(f, d):
    # seats are held, not re-dealt. replay the flag day by day from its
    # first readable row: a holder keeps the seat while it stays eligible,
    # a cut takes back the latest seated first, and open seats go down the
    # line to eligible users who hold none
    if (f, d) in held:
        return held[(f, d)]
    first = reg[f][0][0]
    day = first
    state = []          # [(user, seated_on, line_pos)] in seating order
    while day <= d:
        if (f, day) in held:
            state = held[(f, day)]
        else:
            r = row(f, day)
            n = int(r["seats"]) if r and r["status"].lower() == "active" and r["seats"] else None
            if n is None:
                state = []
            else:
                order = line(day)
                pos = dict((u, i) for i, u in enumerate(order))
                keep = [h for h in state if h[0] in pos and pre_seat(f, h[0], day)[0] == "yes"]
                while len(keep) > n:
                    keep.remove(max(keep, key=lambda h: (h[1], h[2])))
                have = set(h[0] for h in keep)
                for u in order:
                    if len(keep) >= n:
                        break
                    if u not in have and pre_seat(f, u, day)[0] == "yes":
                        keep.append((u, day, pos[u]))
                state = keep
            held[(f, day)] = state
        day = day + timedelta(days=1)
    return state


def cyc(f, d):
    seen = [f]
    nxt = row(f, d)["prereq"].lower()
    while nxt:
        if nxt in seen:
            return True
        if not live(nxt, d) or row(nxt, d) is None:
            return False
        seen.append(nxt)
        nxt = row(nxt, d)["prereq"].lower()
    return False


def pre_seat(f, u, d):
    if f not in reg:
        return "no", "unknown flag"
    if not live(f, d):
        return "no", "prelaunch"
    r = row(f, d)
    if r is None:
        return "no", "invalid registry"
    if r["status"].lower() == "kill":
        return "no", "killed"
    pq = r["prereq"].lower()
    if pq:
        if not live(pq, d):
            return "no", "missing prereq " + pq
        if cyc(f, d):
            return "no", "cycle through " + pq
        if ans(pq, u, d)[0] == "no":
            return "no", "prereq " + pq
    p = as_of(u, d)
    for t in rules.get(f, []):
        a, op, v = t["attribute"].lower(), t["op"].lower(), t["value"].lower()
        if (p[a].lower() == v) != (op == "is_not"):
            return t["verdict"].lower(), "rule %s %s %s" % (a, op, v)
    return r["fallback"].lower(), "fallback"


def ans(f, u, d):
    res = pre_seat(f, u, d)
    if res[0] == "yes":
        s = row(f, d)["seats"]
        if s and u not in [h[0] for h in holders(f, d)]:
            return "no", "seats full"
    return res


out = []
cnt = {}
yes = 0
for c in rd(sys.argv[4]):
    u, f, d = c["user_id"].lower(), c["flag"].lower(), ymd(c["asked"])
    if u not in prof:
        res = ("no", "unknown user")
    elif since[u] > d:
        res = ("no", "unenrolled")
    else:
        res = ans(f, u, d)
    k = res[1].split(" ")[0]
    cnt[k] = cnt.get(k, 0) + 1
    yes += res[0] == "yes"
    out.append("%s  %s  %s  %s  %s  %s" % (c["check_id"], c["asked"], c["user_id"], c["flag"], res[0], res[1]))

nchk = len(out)
for k in ("rule", "fallback", "prereq", "seats", "killed", "cycle", "missing", "invalid", "unknown", "prelaunch", "unenrolled"):
    if k in cnt:
        out.append("%s: %d" % (k, cnt[k]))
out.append("skipped rules: %d" % bad_rules)
out.append("skipped profiles: %d" % bad_prof)
tot = "checks=%d yes=%d no=%d" % (nchk, yes, nchk - yes)
out.append(tot)
print("\n".join(out))
sys.stderr.write(tot + "\n")
