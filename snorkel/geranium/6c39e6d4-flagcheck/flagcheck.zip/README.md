# flagcheck

Answers a support batch against flag_rules.txt. Pass the four exports
in this order:

    python3 flagcheck.py flags.csv rules.csv users.csv checks.csv > flag_answers.txt

Check lines, reason counts, the two skipped lines and the totals go to
stdout. The totals line also goes to stderr, so a cron run shows the
shape of the batch without opening the file. Standard library only.

## What to watch for

Every check is answered as of its own date. The registry row, the
user's profile, the seat holders and the prerequisite chain are all
worked out for that day, so there is no single settled registry to
build once and reuse.

Registry rows are ordered by effective date, not by where they sit in
the export. File position only breaks a tie between two rows on the
same date. An unusable row is passed over and the row before it keeps
standing.

Dates have to be real. A profile or registry row with a date like
2026-02-30 or 2026-3-09 never takes effect, and a user's enrolment
date comes from their earliest readable row.

The step order matters. unknown user and unenrolled come before
anything about the flag. prelaunch comes before invalid registry. A
prerequisite that is not in effect on the date is a missing prereq,
not a prereq failure. A dependent of a killed or full prerequisite
reports prereq.

Seats are counted over everyone enrolled by the check date, not over
the batch, and a user only takes a seat when every step up to fallback
says yes that day. The seat line itself never changes: it is enrolment
date, then first row in users.csv. What a profile change can do is make
an earlier-enrolled user eligible, and that user then takes a seat
before anyone who enrolled later, which can push a later user out.
