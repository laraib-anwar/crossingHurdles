# flagcheck

Answers a support batch against flag_rules.txt. Pass the four exports
in this order:

    python3 flagcheck.py flags.csv rules.csv users.csv checks.csv > flag_answers.txt

Check lines, reason counts, the two skipped lines and the totals go to
stdout. The totals line also goes to stderr, so a cron run shows the
shape of the batch without opening the file. Standard library only.

## What to watch for

Every check is answered as of its own date. The registry row, the
user's profile, the seat holders and the prerequisite chain are all
worked out for that day, so there is no single settled registry to
build once and reuse.

Registry rows are ordered by effective date, not by where they sit in
the export. File position only breaks a tie between two rows on the
same date. An unusable row is passed over and the row before it keeps
standing.

Dates have to be real. A profile or registry row with a date like
2026-02-30 or 2026-3-09 never takes effect, and a user's enrolment
date comes from their earliest readable row.

The step order matters. unknown user and unenrolled come before
anything about the flag. prelaunch comes before invalid registry. A
prerequisite that is not in effect on the date is a missing prereq,
not a prereq failure. A dependent of a killed or full prerequisite
reports prereq.

Seats are held, not re-dealt. For a capped flag the tool replays the
rollout one day at a time from the flag's first row up to the check
date: holders who still pass up to fallback keep their seats, a cut
takes back the most recently seated first, and open seats go down the
enrolment line (enrolment date, then the position of each user's
earliest readable row in users.csv) to eligible users who hold none.
So a user who becomes eligible after the seats fill waits, however
early they enrolled. A seat-capped prerequisite is replayed the same
way, and losing its seat costs the dependent seat too. Each flag and
day is worked once and kept, so the replay stays quick.
