# commission_run

Builds the August commission statement from the quarter's deals and
churns, per comp_rules.txt. Run:

    python3 commission_run.py reps.csv deals.csv churns.csv

The statement goes to stdout and one line goes to stderr:

    reps=6 attainment=332749100 gross=38533370 clawback=3912000 net=34621370 churns=3

commission_2026_08.txt is that run, a short note first and then the
statement in full: a block per rep, then the churns with what each
took back.

What to watch for. Deals are worked in close date order, whatever
order deals.csv lists them, and what a deal pays is fixed at the
moment it credits. The rates are marginal against quota at that
moment, so a deal that crosses a band boundary pays in parts, and
eight deals in this file do, three of them across the full quota line
rather than the half.

Clawbacks are historical. A churned deal is taken back at exactly
what was earned on it, part by part, at the rates of the day it
credited. One churn here takes back a deal that had itself
carried the rep across the full quota line, so part of it was earned at
14 percent and part at 11, 2040000 cents. Re-price it at the churn
day's rates instead, taking the 18000000 back down from the 48000000
the rep stood at that day, and it comes to 2220000, 180000 cents
heavy. The churn also lowers attainment for
everything after it: the same rep's next deal pays at 11 percent
where a build that ignores the churn pays 14.

Splits credit owner first, then partner, on the same day, and each
half is rated against that rep's own attainment, so the churned split
deal takes back two different amounts from its two reps.

A churn naming a deal that never credited changes nothing, and there
is one in the file.

If the deal or churn files change, rerun and diff against the
committed statement before payroll sees it. The per rep blocks move
before the totals visibly do.

The run kept here is the statement for August, not for the quarter,
which closes in September. deals.csv was pulled on the run morning and
already carries one September deal, d-142 for r-863; it belongs to
next month's statement and is not worked here. The file is named for
the month it covers, commission_2026_08.txt.

d-129 carries a 25 in the split column with no partner named, and
nothing in the three files says why. Credit goes to the owner in full unless a
partner is named, so r-425 takes all 4000000.
