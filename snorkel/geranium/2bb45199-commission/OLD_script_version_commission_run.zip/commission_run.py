#!/usr/bin/env python3
# python3 commission_run.py reps.csv deals.csv churns.csv > commission_2026_08.txt

import csv
import sys
from fractions import Fraction

if len(sys.argv) != 4:
    sys.exit("usage: commission_run.py reps.csv deals.csv churns.csv")

def load(fn):
    with open(fn, newline="") as fh:
        return list(csv.DictReader(fh))

def rnd(x):
    if x < 0:
        return -rnd(-x)
    return int(x + Fraction(1, 2))

def pay(q, at, amt):
    tot = 0
    at = Fraction(at)
    amt = Fraction(amt)
    for cap, pct in ((Fraction(q, 2), 8), (Fraction(q), 11), (None, 14)):
        if amt == 0:
            break
        if cap is None:
            piece = amt
        elif at >= cap:
            continue
        else:
            piece = min(amt, cap - at)
        tot += rnd(piece * pct / 100)
        at += piece
        amt -= piece
    return tot

order = []
quota = {}
for r in load(sys.argv[1]):
    order.append(r["rep_id"].strip())
    quota[order[-1]] = int(r["quota_cents"])

ev = []
for i, r in enumerate(load(sys.argv[2])):
    if r["close_date"].strip() > "2026-08-31":
        continue    # september, next month's statement
    ev.append((r["close_date"].strip(), 0, i, r))
for i, r in enumerate(load(sys.argv[3])):
    ev.append((r["churn_date"].strip(), 1, i, r))
ev.sort(key=lambda e: e[:3])

att = {r: 0 for r in order}
gross = {r: 0 for r in order}
back = {r: 0 for r in order}
booked = {}
churned = []

for day, is_churn, i, r in ev:
    d = r["deal_id"].strip()
    if is_churn:
        took = 0
        for rep, cr, c in booked.pop(d, []):
            att[rep] -= cr
            back[rep] += c
            took += c
        churned.append((day, d, took))
        continue
    amt = int(r["amount_cents"])
    who = [(r["rep"].strip(), amt)]
    if r["partner"].strip():
        p = amt * int(r["split_pct"] or 0) // 100
        who = [(r["rep"].strip(), amt - p), (r["partner"].strip(), p)]
    booked[d] = []
    for rep, cr in who:
        c = pay(quota[rep], att[rep], cr)
        att[rep] += cr
        gross[rep] += c
        booked[d].append((rep, cr, c))

A = sum(att.values())
G = sum(gross.values())
C = sum(back.values())

print("commission statement through 2026-08-31")
print("reps %d, attainment %d, gross %d, clawed back %d, net %d" % (len(order), A, G, C, G - C))
for rep in order:
    q = quota[rep]
    t = (att[rep] * 2000 + q) // (2 * q)
    print()
    print("rep " + rep)
    print("  attainment %d, %d.%d%% of quota" % (att[rep], t // 10, t % 10))
    print("  gross %d" % gross[rep])
    if back[rep]:
        print("  clawback %d" % back[rep])
    print("  net %d" % (gross[rep] - back[rep]))
print()
print("churns")
for day, d, took in churned:
    print("  %s  %-7s took back %d" % (day, d, took))

print("reps=%d attainment=%d gross=%d clawback=%d net=%d churns=%d"
      % (len(order), A, G, C, G - C, len(churned)), file=sys.stderr)
