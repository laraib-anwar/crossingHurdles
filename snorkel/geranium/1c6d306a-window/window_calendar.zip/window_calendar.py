#!/usr/bin/env python3
# Monthly maintenance calendar from the standing bookings, per window_rules.txt
#   python3 window_calendar.py recurring.csv changes.csv freezes.csv 2026-09 > september_windows.txt

import csv
import sys
from datetime import date, datetime, timedelta

if len(sys.argv) != 5:
    sys.exit("usage: window_calendar.py recurring.csv changes.csv freezes.csv YYYY-MM")
rec_file, chg_file, frz_file, month = sys.argv[1:]

WEEKDAY = {"mon": 0, "tue": 1, "wed": 2, "thu": 3, "fri": 4, "sat": 5, "sun": 6}


def d(s):
    y, m, dd = s.strip().split("-")
    return date(int(y), int(m), int(dd))


def mins(s):
    h, m = s.strip().split(":")
    return int(h) * 60 + int(m)


def hhmm(n):
    return "%02d:%02d" % ((n // 60) % 24, n % 60)


def ym(day):
    return day.strftime("%Y-%m")


def starts(w, day=None):
    day = day or w["date"]
    return datetime(day.year, day.month, day.day) + timedelta(minutes=w["start"])


with open(frz_file) as f:
    freeze = [(d(r["start_date"]), d(r["end_date"]), r["reason"].strip()) for r in csv.DictReader(f)]


def frozen(day):
    return next((why for a, b, why in freeze if a <= day <= b), None)


with open(chg_file) as f:
    reqs = list(csv.DictReader(f))

# build the month plus one day each side (overnights cross the boundary),
# plus any date a request names, so a move can find its source occurrence
first = date(int(month[:4]), int(month[5:7]), 1)
days = [first - timedelta(days=1)]
cur = first
while ym(cur) == month:
    days.append(cur)
    cur += timedelta(days=1)
days.append(cur)
days = sorted(set(days) | {d(r["date"]) for r in reqs if r["date"].strip()})

book = []
with open(rec_file) as f:
    for r in csv.DictReader(f):
        wd = WEEKDAY[r["weekday"].strip().lower()]
        lo = d(r["effective_from"])
        hi = d(r["effective_to"]) if r["effective_to"].strip() else None
        for day in days:
            if day.weekday() == wd and day >= lo and not (hi and day > hi):
                book.append({"id": r["window_id"].strip(), "service": r["service"].strip(),
                             "date": day, "start": mins(r["start_time"]), "dur": int(r["duration_min"]),
                             "slip": (r.get("slip") or "no").strip() == "yes"})

bad = 0

# withdrawals first: only a non-withdraw request filed above it, once
row_of = {r["change_id"].strip(): r for r in reqs}
pos_of = {r["change_id"].strip(): i for i, r in enumerate(reqs)}
pulled = set()
for i, r in enumerate(reqs):
    if r["kind"].strip() != "withdraw":
        continue
    tgt = r["window_id"].strip()
    if tgt not in row_of or pos_of[tgt] > i or row_of[tgt]["kind"].strip() == "withdraw" or tgt in pulled:
        bad += 1
    else:
        pulled.add(tgt)


def find(wid, day):
    return [w for w in book if w["id"] == wid and w["date"] == day]


for r in reqs:
    kind = r["kind"].strip()
    if kind == "withdraw" or r["change_id"].strip() in pulled:
        continue
    # only requests touching this month run (or count as invalid) here
    if not any(t.strip() and ym(d(t)) == month for t in (r["date"], r["new_date"])):
        continue
    wid = r["window_id"].strip()
    on = d(r["date"]) if r["date"].strip() else None
    if kind == "skip":
        got = find(wid, on)
        if got:
            book.remove(got[0])
        else:
            bad += 1
    elif kind == "move":
        got = find(wid, on)
        to = d(r["new_date"])
        if not got or frozen(to):
            bad += 1
            continue
        got[0]["date"] = to
        if r["new_start"].strip():
            got[0]["start"] = mins(r["new_start"])
    elif kind == "add":
        if frozen(on):
            bad += 1
            continue
        book.append({"id": r["change_id"].strip(), "service": r["service"].strip(),
                     "date": on, "start": mins(r["new_start"]), "dur": int(r["duration_min"])})
    elif kind == "end_series":
        gone = [w for w in book if w["id"] == wid and w["date"] >= on]
        if not gone:
            bad += 1
        for w in gone:
            book.remove(w)

held = []
for w in list(book):
    why = frozen(w["date"])
    if why:
        w["why"] = why
        held.append(w)
        book.remove(w)

placed, lost = [], []


def clash(w, day):
    # same service, overlapping time, against anything already placed
    a = starts(w, day)
    b = a + timedelta(minutes=w["dur"])
    for k in placed:
        if k["service"] == w["service"]:
            ka = starts(k)
            if a < ka + timedelta(minutes=k["dur"]) and ka < b:
                return k["id"]
    return None


def order(w):
    return (starts(w), w["id"])


# s.4: fixed windows take their slots first, slippers fit round them
for w in sorted([w for w in book if not w.get("slip")], key=order):
    who = clash(w, w["date"])
    if who:
        w["winner"] = who
        lost.append(w)
    else:
        placed.append(w)

for w in sorted([w for w in book if w.get("slip")], key=order):
    # up to three days later, never out of the occurrence's own month
    home, day, ok = ym(w["date"]), w["date"], False
    for n in range(4):
        if n:
            day += timedelta(days=1)
            if ym(day) != home:
                break
        if not frozen(day) and clash(w, day) is None:
            w["date"] = day
            placed.append(w)
            ok = True
            break
    if not ok:
        w["winner"] = "no slot"
        lost.append(w)

# The day before and the day after the month were built only so the
# conflict pass could see overnight windows crossing the boundary.
# Everything printed below - day blocks, suppressed, bumped - is limited
# to dates inside the month asked for on the command line.
def in_requested_month(w):
    return w["date"].strftime("%Y-%m") == month


cal = [w for w in placed if in_requested_month(w)]
held = [w for w in held if in_requested_month(w)]
lost = [w for w in lost if in_requested_month(w)]

per_day = {}
for w in cal:
    per_day.setdefault(w["date"], []).append(w)

print("maintenance calendar for %s" % month)
for day in sorted(per_day):
    print()
    print(day.isoformat())
    for w in sorted(per_day[day], key=lambda w: (w["start"], w["id"])):
        print("  %s-%s  %s  %s" % (hhmm(w["start"]), hhmm(w["start"] + w["dur"]), w["service"], w["id"]))
print()
print("suppressed")
for w in sorted(held, key=lambda w: (w["date"], w["start"], w["id"])):
    print("  %s  %s  %s  %s  %s" % (w["date"].isoformat(), hhmm(w["start"]), w["service"], w["id"], w["why"]))
print()
print("bumped")
for w in sorted(lost, key=lambda w: (w["date"], w["start"], w["id"])):
    why = ("found no free day within three days" if w["winner"] == "no slot"
           else "lost the slot to %s" % w["winner"])
    print("  %s  %s  %s  %s  %s" % (w["date"].isoformat(), hhmm(w["start"]), w["service"], w["id"], why))
print()
print("invalid requests: %d" % bad)

sys.stderr.write("days=%d windows=%d suppressed=%d bumped=%d invalid=%d\n"
                 % (len(per_day), len(cal), len(held), len(lost), bad))
