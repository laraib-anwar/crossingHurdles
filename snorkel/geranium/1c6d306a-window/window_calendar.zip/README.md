# window_calendar

Builds the month's maintenance calendar from the standing bookings,
the change requests and the freeze list, per window_rules.txt.

    python3 window_calendar.py recurring.csv changes.csv freezes.csv 2026-09

The calendar prints to stdout and one totals line goes to stderr:

    days=25 windows=48 suppressed=9 bumped=9 invalid=8

september_windows.txt is that run, a short note and then the calendar.

What to watch for.

Requests are judged in file order against the schedule as it stands at
that moment. A withdrawal can leave a later request pointing at a date
that no longer holds anything.

Placement order is the other trap. Windows marked slip no are placed
before any window that can move. Only then do the slippable ones step
forward, up to three days, over frozen or busy days.

Resolving the conflicts in one sweep over the original dates puts two
ledger windows on the same day. L-301 slips off Sunday the 6th onto
Wednesday the 9th, which is L-305's own day, so L-305 has to move to
the 10th.

Freezes apply after the change pass for standing bookings. A move or an
add aimed into a freeze is refused.

Overnight windows belong to their start date, and their span is measured
on the real clock across midnight, so one can collide with the next
morning's window of the same service. Windows of different services
never collide, whatever the clock says. The last day of the previous month gets built even though it
never shows here, and the report is limited to the month asked for.
