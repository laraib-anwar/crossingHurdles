#!/usr/bin/env python3
# Recall trace for one lot, per recall_rules.txt
#   python3 trace_recall.py batches.csv blends.csv shipments.csv b-1102 > recall_notice.txt

import csv
import sys
from fractions import Fraction

if len(sys.argv) != 5:
    sys.exit("usage: trace_recall.py batches.csv blends.csv shipments.csv LOT")

LIMIT = Fraction(1, 200)     # at or over this gets pulled


def rows(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


kg, name = {}, {}
for r in rows(sys.argv[1]):
    kg[r["batch_id"].strip()] = int(r["size_kg"])
    name[r["batch_id"].strip()] = r["product"].strip()

inputs = {}
for r in rows(sys.argv[2]):
    inputs.setdefault(r["into_batch"].strip(), []).append((r["from_batch"].strip(), int(r["kg_used"])))

shipments = rows(sys.argv[3])
lot = sys.argv[4].strip()

share = {lot: Fraction(1)}


def dose(b):
    # blends.csv isn't in dependency order, so work each batch from its inputs
    if b not in share:
        share[b] = sum((dose(src) * Fraction(used, kg[b]) for src, used in inputs.get(b, [])),
                       Fraction(0))
    return share[b]


touched = [b for b in kg if b != lot and dose(b) > 0]
pulled = [b for b in touched if dose(b) >= LIMIT]
passed = [b for b in touched if dose(b) < LIMIT]
pulled_kg = sum(kg[b] for b in pulled)
hit = [s for s in shipments if s["batch_id"].strip() in pulled]


def ppm(f):
    # report only, rounded half up
    x = f * 1000000
    return (2 * x.numerator + x.denominator) // (2 * x.denominator)


def worst_first(bs):
    return sorted(bs, key=lambda b: (-dose(b), b))


print("trace for lot %s" % lot)
print("touched %d, recalled %d, kilograms recalled %d" % (len(touched), len(pulled), pulled_kg))
print()
for tag, group in (("recalled", pulled), ("cleared", passed)):
    for b in worst_first(group):
        print("  %-7s %-22s %6d ppm  %5d kg  %s" % (b, name[b], ppm(dose(b)), kg[b], tag))
print()
print("affected shipments")
for s in hit:
    print("  %-7s %-14s %-7s %5d kg" % (s["shipment_id"].strip(), s["customer"].strip(),
                                        s["batch_id"].strip(), int(s["kg_sent"])))

sys.stderr.write("touched=%d recalled=%d cleared=%d kg_recalled=%d shipments=%d\n"
                 % (len(touched), len(pulled), len(passed), pulled_kg, len(hit)))
