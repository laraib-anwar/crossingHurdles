# trace_recall

Works a contamination trace through the quarter's blend records and
produces the recall notice, per recall_rules.txt. Run:

    python3 trace_recall.py batches.csv blends.csv shipments.csv b-1102

The notice goes to stdout and one line goes to stderr:

    touched=9 recalled=4 cleared=5 kg_recalled=2350 shipments=4

recall_notice.txt is that run, a short note first and then the notice
in full: the recalled batches highest fraction first, the cleared
batches with their fractions, and the affected shipments.

What to watch for. The fractions have to be worked in dependency
order, and blends.csv is deliberately in no such order, so resolve
each batch from its ingredients rather than reading the file top to
bottom. Contributions from separate routes into the same batch add
up: the fiesta mix reaches the threshold at exactly one part in
two hundred only because both of its routes are counted, and taking
the strongest route alone clears it wrongly and drops one shipment
off the notice.

The threshold spares a batch, it does not launder it. A cleared batch
still carries its fraction into everything made from it, which is how
a snack seasoning four blends down from the lot ends up on the notice
at 333 parts per million, cleared but traced, with the jar mix it was
made from sitting above it at 1500. And the comparison is exact,
worked in whole arithmetic before any rounding: parts per million are
rounded for the report only, halves up.

Recalling every descendant of the lot is the old policy, and against
these records it pulls 6250 kilograms and six shipments instead of
2350 and four. The whole point of the tool is that difference.

Hand check of the batch on the line. The fiesta mix b-2060 is 600 kg
and takes 45 kg of the bbq base b-2010 and 150 kg of the smoke blend
b-2044. The bbq base holds 40 kg of b-1102 in 1000 kg, a fraction of
40/1000. The smoke blend takes 100 kg of the bbq base into 500 kg, so
it carries 40/1000 x 100/500 = 8/1000. Into the fiesta mix:

    via b-2010   40/1000 x 45/600   = 3/1000 = 3000 ppm
    via b-2044    8/1000 x 150/600  = 2/1000 = 2000 ppm
    total                             5/1000 = 5000 ppm

5/1000 is exactly 1/200, so the batch is recalled, and trace_recall.py
prints b-2060 at 5000 ppm, recalled, the same figure. Either route on
its own falls short of the threshold.

If the blend records change, rerun and diff against the committed
notice before anything is mailed. The fractions move before the
recall list visibly does.
