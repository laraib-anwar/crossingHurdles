import sys, csv

# final league table. usage: standings.py clubs.csv results.csv sanctions.csv
# section numbers in the comments are league_rules.txt

args = sys.argv[1:]
if len(args) < 3:
    print("usage: standings.py clubs.csv results.csv sanctions.csv", file=sys.stderr)
    sys.exit(2)


def rows(path):
    with open(path, newline="") as fp:
        return list(csv.DictReader(fp))


members = []
known_as = {}
for row in rows(args[0]):
    club = row["club"].strip()
    members.append(club)
    known_as[club] = club
    former = (row.get("former_name") or "").strip()
    if former:
        known_as[former] = club   # old name on early results, same club

# sec 1. abandoned rows are nothing at all; a forfeit stands as 3-0
matches = []
for row in rows(args[1]):
    status = row["status"].strip()
    if status == "abandoned":
        continue
    home_g, away_g = int(row["home_goals"]), int(row["away_goals"])
    if status == "forfeit_home":
        home_g, away_g = 0, 3
    elif status == "forfeit_away":
        home_g, away_g = 3, 0
    matches.append((known_as[row["home"].strip()], known_as[row["away"].strip()], home_g, away_g, status))

# every upheld sanction row counts; an overturned one takes nothing
docked = {}
for row in rows(args[2]):
    if row["status"].strip() == "upheld":
        club = row["club"].strip()
        docked[club] = docked.get(club, 0) + int(row["points"])


def standings_for(group):
    rec = {}
    for club in group:
        rec[club] = dict(p=0, w=0, d=0, l=0, gf=0, ga=0, pts=0)
    for home, away, hg, ag, _ in matches:
        if home in rec and away in rec:
            for club, scored, conceded in ((home, hg, ag), (away, ag, hg)):
                r = rec[club]
                r["p"] += 1
                r["gf"] += scored
                r["ga"] += conceded
                if scored > conceded:
                    r["w"] += 1
                    r["pts"] += 3
                elif scored == conceded:
                    r["d"] += 1
                    r["pts"] += 1
                else:
                    r["l"] += 1
    return rec


whole = standings_for(members)
points = {}
for club in members:
    points[club] = whole[club]["pts"] - docked.get(club, 0)
tie_log = []


def separate(group, level):
    # sec 3. mini table first, then season numbers, then the id.
    # a partial split re-ranks the still-level clubs from the top
    if len(group) == 1:
        return group
    mini = standings_for(group)
    ladder = (
        ("points among the tied clubs", lambda c: mini[c]["pts"]),
        ("goal difference among the tied clubs", lambda c: mini[c]["gf"] - mini[c]["ga"]),
        ("goals scored among the tied clubs", lambda c: mini[c]["gf"]),
        ("season goal difference", lambda c: whole[c]["gf"] - whole[c]["ga"]),
        ("season goals scored", lambda c: whole[c]["gf"]),
    )
    for label, measure in ladder:
        values = sorted({measure(c) for c in group}, reverse=True)
        if len(values) == 1:
            continue
        tie_log.append((list(group), label, level))
        placed = []
        for v in values:
            bunch = [c for c in group if measure(c) == v]
            placed += separate(bunch, level + 1) if len(bunch) < len(group) else bunch
        return placed
    tie_log.append((list(group), "the club id, alphabetically", level))
    return sorted(group)


final = []
for p in sorted(set(points.values()), reverse=True):
    final += separate(sorted(c for c in members if points[c] == p), 0)

total_goals = sum(m[2] + m[3] for m in matches)
n_forfeits = sum(1 for m in matches if m[4] != "played")
docked_total = sum(docked.values())

print("final table, 2026 season")
print("clubs %d, matches %d, goals %d, forfeits %d, sanction points %d"
      % (len(members), len(matches), total_goals, n_forfeits, docked_total))
print()
for pos, club in enumerate(final, 1):
    r = whole[club]
    tail = " deducted %d" % docked[club] if club in docked else ""
    print("  %2d  %-10s p%2d w%2d d%2d l%2d  gf%3d ga%3d gd%+4d%s  pts %d"
          % (pos, club, r["p"], r["w"], r["d"], r["l"], r["gf"], r["ga"], r["gf"] - r["ga"], tail, points[club]))
print()
print("tie notes")
for group, label, level in tie_log:
    print("  %s: separated by %s%s" % (" ".join(sorted(group)), "fresh group, " if level else "", label))
print()
print("promoted: %s" % final[0])
print("relegated: %s, %s" % (final[-2], final[-1]))
print("clubs=%d matches=%d goals=%d forfeits=%d sanction_points=%d tied_groups=%d"
      % (len(members), len(matches), total_goals, n_forfeits, docked_total, len(tie_log)), file=sys.stderr)
