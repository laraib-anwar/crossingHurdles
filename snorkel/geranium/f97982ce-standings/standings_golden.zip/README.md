# standings

Builds the season's final table from the results, per league_rules.txt.
Run:

    python3 standings.py clubs.csv results.csv sanctions.csv

The publication goes to stdout and one line goes to stderr:

    clubs=10 matches=45 goals=124 forfeits=1 sanction_points=3 tied_groups=4

standings_2026.txt is that run, a short note first and then the
publication in full: the table, the tie notes, and the promotion and
relegation lines.

What to watch for. Ties break on the mini table first, the matches
among the tied clubs only, and the season numbers come in only after
the mini table is exhausted. This season's top two are level on
points and separated by their head to head, not by goal difference,
which would put them the same way round but for the wrong reason on
appeal.

The fresh group rule is the one that changes positions. When a step
splits some clubs off but leaves two or more still level, those clubs
restart from the top of the list as a group of their own, mini table
rebuilt from just their mutual matches. The thirteen point group here
does exactly that: eastvale drops off on mini table points, and
denton against ashford is then a fresh two club group that ends up on
season goal difference. Continue with the old group's numbers instead
and third and fourth swap.

Third place by hand, as a check on the tool. The three clubs on
thirteen met three times: denton beat eastvale 1 to 0, ashford beat
eastvale 3 to 2, and denton and ashford drew 0 to 0. That mini table
gives ashford 4 points with 3 for and 2 against, denton 4 points with
1 for and 0 against, and eastvale nothing, so eastvale is fifth.
denton and ashford then restart as a fresh group of two. Their one
meeting was 0 to 0, so the new mini table is level on points, goal
difference and goals, and season goal difference decides it, denton
+1 to ashford -2. denton is third, which is what the table prints.

A forfeit counts three nil to the club that did not forfeit, whatever
goals the row records. The abandoned denton against ashford row from
March 7 counts for nothing; only the 0 to 0 replay on April 8 stands,
and it is the replay that sends denton and ashford to season goal
difference. sanctions.csv has one row per sanction, and ironside has
two of them, 2 points and 1, so its deduction is 3. Read the file into
a plain per-club lookup and the later row overwrites the earlier one,
leaving ironside with only the 1 point and on 12 instead of 10. Deductions come off
section 2 points only and never enter a mini table.

eastvale re-registered this season and results.csv still carries its old name, eastvale_rovers, on the four
March matches; clubs.csv gives the former name, so those matches are
eastvale's. Drop them and eastvale is relegated on 8 points.

sanctions.csv also holds a 2 point sanction on fairmont that was overturned
on appeal. It takes nothing; count it and the deductions come to 5.

If the results change, rerun and diff against the committed
publication before anything goes out. The tie notes move before the
table visibly does.

Panel outcomes are run on copies, never on the league's own files. The
tool reads only the three record files, so for the ironside appeal
copy sanctions.csv and change the status on the 2 point ironside row
to anything other than upheld, and for the fairmont protest copy
results.csv and set the March 21 fairmont against ironside row to
forfeit_home. For the denton appeal copy results.csv, set the March 7
denton against ashford row to played and the April 8 replay row to
abandoned, so the tool counts the 2 to 0 and ignores the replay. Point
the tool at the copies and leave standings_2026.txt as it is; its note
already gives the order, promotion and relegation for all eight
combinations of the three cases.
