# trueup

trueup.py settles the summer for the six water accounts in reads.csv.
It works the September the 1st true ups under billing_rules.txt and
prints the September statement batch.

## Running it

    python3 trueup.py reads.csv tariff.csv

reads.csv goes first and tariff.csv second. The statement prints to
stdout and stderr gets one tally line, which for this batch reads

    accounts=6 august=147115 trueup=20640 corrected=5 due=167755

statement_2026_09.txt holds this month's run: a short note on what
moved, then the batch as printed. Each account shows its August charge,
then any corrected months and its true up amount, then its amount due.
a-3117 had nothing to correct, so its block is the August charge and
the amount due and nothing between them.

## Where a true up goes wrong

Spans. A September actual closes a span that starts at that account's
previous actual, not at the start of summer, so an account with an
actual in the middle of summer only corrects the months after it.
August is billed from the corrected books because it was never billed
before; the true up amount covers only the earlier months of the span.

Spreading units. Units are spread by days in each month, never by what
the estimates said. Only whole units go out, the remainder goes by
largest fractional part, and a tie goes to the earlier month. That tie
rule settles a remainder unit in all five corrected spans, and in
three of them it settles the only spare unit. In a-4501 and a-2933 the
first spare unit goes to June outright on the highest fraction. a-4501
then has one unit left, which the tie gives to May; a-2933 has two
left, which the tie gives to May and July.

Pricing. Each corrected month is priced under its own month's tariff.
The tariff rose on August the 1st, so a unit spread into July instead
of August changes the money even when the unit counts are right.
Spread by the estimates and the batch total moves by over a hundred
dollars; price corrected months at the current tariff and the true up
total is wrong by a little over two hundred and sixty dollars.

Credits. One account was over estimated enough that its September
amount due is negative. It stays negative on the statement rather than
being floored at zero.

## Before anything prints

If the reads or the tariff change, rerun and diff against
statement_2026_09.txt. A small change often shows in one account's
corrected month lines while the totals at the top still read the same,
because one account's true up can offset another's, so read the per
account blocks rather than the summary line.
