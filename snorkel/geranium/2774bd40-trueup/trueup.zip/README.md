# trueup

Builds the September statement batch from the summer's meter reads,
per billing_rules.txt. Run:

    python3 trueup.py reads.csv tariff.csv

The statement goes to stdout and one line goes to stderr:

    accounts=6 august=147115 trueup=20640 corrected=5 due=167755

statement_2026_09.txt is that run, a short note first and then the
batch in full: each account's August charge, then its corrected months
and its true up amount where it has either, and its amount due. One
account in this batch has neither, so its block is the August charge
and the amount due and nothing between them.

What to watch for. The span a September actual closes starts at that
account's previous actual, not at the start of summer, so an account
with a mid summer actual only corrects the months after it. August is
billed straight from the corrected books because it was never billed
before; the true up amount covers only the earlier months of the span.

The spread is by days in each month, never by what the estimates said.
Whole units only, remainder handed out by largest fractional part with
ties to the earlier month, and the tie rule settles a remainder unit in
all five corrected spans. In three of them it settles the only spare
unit. In a-4501 and a-2933 the first spare unit goes to June outright on
the highest fraction, and the tie decides the unit after it. Then each
corrected month is priced under its own month's tariff. The tariff
rose on August the 1st, so spreading a unit into July
instead of August changes the money even when the units are right.
Spread by the estimates and the batch total moves by over a hundred
dollars; price corrected months at the current tariff and the true up
total is wrong by a little over two hundred and sixty dollars.

Credits are real. One account here was over estimated enough that its
September amount due is negative, and it should stay negative on the
statement rather than being floored at zero.

If you change the reads or the tariff, rerun and diff against the
committed statement before anything prints. A small change often shows
in an account's corrected month lines while the batch totals at the
top of the statement still read the same, because one account's
true up can offset another's, so read the per account blocks rather
than the summary line.
