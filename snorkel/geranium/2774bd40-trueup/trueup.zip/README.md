# trueup

trueup.py settles the summer for the water accounts in reads.csv. It
works the true ups that the September the 1st actuals close, under
billing_rules.txt, and prints the statement batch. The month names on
the statement come from the read dates, so the same script serves next
month's batch.

## Running it

    python3 trueup.py reads.csv tariff.csv

reads.csv goes first and tariff.csv second. The statement prints to
stdout and stderr gets one tally line, which for this batch reads

    accounts=14 august=369115 trueup=70420 corrected=11 due=439535

statement_2026_09.txt holds this month's run: a short note on what
moved, then the batch as printed. a-3117, a-7702 and a-9035 had nothing
to correct, so each block is the August charge and the amount due and
nothing between them.

## One account by hand: a-4501

a-4501 read 1180 on May the 1st, an actual, then three estimates, then
1352 on September the 1st, also actual. The span is May to August and
its true usage is 1352 minus 1180, 172 units, over 31, 30, 31 and 31
days, 123 days in all.

By days the shares are 43.35 for May, 41.95 for June, 43.35 for July
and 43.35 for August. The whole units come to 43, 41, 43 and 43, which
is 170, so 2 units are spare. The first goes to June on its .95. The
other three months are level on .35, and the tie gives the second unit
to May, the earliest. Corrected usage is 44, 42, 43 and 43.

May to July are priced under the January tariff, 30 units at 410 cents
and the rest at 655: 21470, 20160 and 20815 cents, 62445 in all. They
were billed on the estimates at 30, 28 and 28 units, 12300, 11480 and
11480 cents, 35260 in all. The true up is 62445 minus 35260, 27185
cents. August is priced under the August tariff, 30 units at 445 and
13 at 720, 22710 cents. The amount due is 22710 plus 27185, 49895
cents, which is what the statement prints for a-4501.

## Where a true up goes wrong

Spans. A September actual closes a span that starts at that account's
previous actual, not at the start of summer, so an account with an
actual in the middle of summer only corrects the months after it.
a-9035's August the 1st read was actual, so its span is August alone
and nothing earlier is reopened.

August. The August month is billed from the corrected books because it
was never billed before; the true up amount covers only the earlier
months of the span.

Spreading units. Units go out by days in each month, never by what the
estimates said, in whole units, with the remainder by largest
fractional part and a tie to the earlier month. The tie decides a unit
in six of the eleven corrected spans: a-4501, a-2933, a-5169, a-1846,
a-6220 and a-4127. a-2933 has three spare units, the first to June
outright and the other two by the tie to May and July. a-6618 and
a-3364 also have three spare units, but three months share the top
fraction, so each of them gets one and the order never matters.

Pricing. Each corrected month is priced under its own month's tariff.
The tariff rose on August the 1st, so a unit spread into July instead
of August changes the money even when the unit counts are right.
Spread by the estimates and the batch total moves by 338.55 dollars;
price corrected months at the current tariff and the true up total is
wrong by 619 dollars.

Credits. a-2933 and a-6618 were over estimated enough that their
September amounts due are negative. They stay negative on the
statement rather than being floored at zero.

## Before anything prints

If the reads or the tariff change, rerun and diff against
statement_2026_09.txt. A small change often shows in one account's
corrected month lines while the totals at the top still read the same,
because one account's true up can offset another's, so read the per
account blocks rather than the summary line.
