#!/usr/bin/env python3
# statement batch per billing_rules.txt, named for the month of the closing read
#   python3 trueup.py reads.csv tariff.csv > statement_2026_09.txt

import csv
import sys
from datetime import date

if len(sys.argv) != 3:
    sys.exit("usage: trueup.py reads.csv tariff.csv")


def ymd(s):
    y, m, d = s.strip().split("-")
    return date(int(y), int(m), int(d))


with open(sys.argv[2], newline="") as f:
    tariff = sorted((r["effective_from"].strip(), int(r["block_units"]),
                     int(r["block_price_cents"]), int(r["upper_price_cents"]))
                    for r in csv.DictReader(f))


def charge(month, units):
    # rate in force = last row effective by that month
    block, lo, hi = [t[1:] for t in tariff if t[0] <= month][-1]
    first = min(units, block)
    return first * lo + (units - first) * hi


accts = []
rd = {}
with open(sys.argv[1], newline="") as f:
    for r in csv.DictReader(f):
        a = r["ACCOUNT"].strip()
        if a not in rd:
            accts.append(a)
            rd[a] = {}
        mo, dy, yr = r["READ_DATE"].strip().split("/")
        # read code A = actual, E = estimated; route, meter, trouble code etc. don't bill
        rd[a]["%s-%s-%s" % (yr, mo, dy)] = (int(r["READING"]), r["READ_CODE"].strip().upper())

dates = sorted({d for a in accts for d in rd[a]})
months, close = dates[:-1], dates[-1]
ndays = {m: (ymd(dates[i + 1]) - ymd(m)).days for i, m in enumerate(months)}
aug = months[-1]


def name(d):
    return ymd(d).strftime("%B").lower()


AUG, STMT = name(aug), name(close)


def spread(units, span):
    # s.4: by days, whole units, leftovers to biggest remainder, ties earlier
    tot_days = sum(ndays[m] for m in span)
    got = {m: units * ndays[m] // tot_days for m in span}
    rem = sorted(range(len(span)), key=lambda i: (-(units * ndays[span[i]] % tot_days), i))
    for i in rem[:units - sum(got.values())]:
        got[span[i]] += 1
    return got


sum_aug = sum_true = sum_due = n_fixed = 0
out = []
for a in accts:
    used = {m: rd[a][dates[i + 1]][0] - rd[a][m][0] for i, m in enumerate(months)}
    # span opens at the last actual before the closing read, and only an
    # actual closing read can close it; an estimated close bills August as read
    first = max([i for i, m in enumerate(months) if rd[a][m][1] == "A"] or [0])
    span = months[first:] if rd[a][close][1] == "A" else months[-1:]
    block = ["account " + a]
    if len(span) == 1:
        c = charge(aug, used[aug])
        block.append("  %s  %4d units  %7d" % (AUG, used[aug], c))
        due = c
    else:
        fix = spread(rd[a][close][0] - rd[a][span[0]][0], span)
        c = charge(aug, fix[aug])
        block.append("  %s  %4d units  %7d  corrected from the span" % (AUG, fix[aug], c))
        tu = 0
        for m in span[:-1]:
            now, was = charge(m, fix[m]), charge(m, used[m])
            tu += now - was
            block.append("  %s corrected to %4d units %7d, billed %4d units %7d"
                         % (m[:7], fix[m], now, used[m], was))
        block.append("  true up %d" % tu)
        sum_true += tu
        n_fixed += 1
        due = c + tu
    block.append("  due %d" % due)
    sum_aug += c
    sum_due += due
    out.append(block)

print("%s statement from reads.csv" % STMT)
print("accounts %d, %s %d, true up %d, corrected %d" % (len(accts), AUG, sum_aug, sum_true, n_fixed))
for block in out:
    print()
    print("\n".join(block))
sys.stderr.write("accounts=%d august=%d trueup=%d corrected=%d due=%d\n"
                 % (len(accts), sum_aug, sum_true, n_fixed, sum_due))
