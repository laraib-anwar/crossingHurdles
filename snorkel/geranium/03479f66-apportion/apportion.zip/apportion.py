import csv
import json
import sys

# tenants.csv usage_history.csv period.json, table on stdout
if len(sys.argv) != 4:
    sys.exit("usage: apportion.py tenants.csv usage_history.csv period.json")

tenants = []
f = open(sys.argv[1], newline="")
for row in csv.DictReader(f):
    tenants.append({"id": row["tenant_id"].strip(), "name": row["name"].strip(),
                    "plan": row["plan"].strip(), "weight": int(row["weight"]),
                    "floor": int(row["floor_calls"]), "ceil": int(row["ceiling_calls"])})
f.close()

peak = {}
f = open(sys.argv[2], newline="")
for row in csv.DictReader(f):
    tid = row["tenant_id"].strip()
    n = int(row["calls_used"])
    if n > peak.get(tid, 0):
        peak[tid] = n
f.close()

f = open(sys.argv[3])
per = json.load(f)
f.close()

budget = per["pool_calls"] - per["reserve_calls"]
suspended = set(per["suspended"])
active = [t for t in tenants if t["id"] not in suspended]

final = {}
status = {}
while True:
    free = [t for t in active if t["id"] not in final]
    if not free:
        break
    left = budget - sum(final.values())
    wsum = 0
    for t in free:
        wsum += t["weight"]
    if wsum == 0:
        sys.exit("free tenants all have weight 0, can't divide")
    share = {}
    for t in free:
        share[t["id"]] = left * t["weight"] // wsum

    # policy 3: first tenant out of range in registry order gets pinned, then redo
    hit = None
    for t in free:
        if share[t["id"]] > t["ceil"] or share[t["id"]] < t["floor"]:
            hit = t
            break
    if hit:
        if share[hit["id"]] > hit["ceil"]:
            final[hit["id"]] = hit["ceil"]
            status[hit["id"]] = "at ceiling"
        else:
            final[hit["id"]] = hit["floor"]
            status[hit["id"]] = "at floor"
        continue

    # policy 4: spare calls one each, biggest fraction first, tie to lower id
    extra = left - sum(share.values())
    line = sorted(free, key=lambda t: (-(left * t["weight"] % wsum), t["id"]))
    getting = line[:extra]
    # one more call would put a tenant sitting on its ceiling over it,
    # so pin that one there and divide again
    stuck = None
    for t in free:
        if t in getting and share[t["id"]] == t["ceil"]:
            stuck = t
            break
    if stuck:
        final[stuck["id"]] = stuck["ceil"]
        status[stuck["id"]] = "at ceiling"
        continue
    for t in getting:
        share[t["id"]] += 1
    final.update(share)
    break

print("apportionment for %s" % per["period"])
print("pool %d, reserve %d, apportioned %d" % (per["pool_calls"], per["reserve_calls"], budget))
print()
total = 0
for t in tenants:
    if t["id"] in suspended:
        print("%s  suspended" % t["id"])
        continue
    n = final[t["id"]]
    total += n
    short = peak.get(t["id"], 0) - n
    if short > 0:
        cover = "under peak by %d" % short
    else:
        cover = "covers peak"
    print("%s  %-24s %-8s %8d  %-10s %s" % (t["id"], t["name"], t["plan"], n,
                                           status.get(t["id"], "by weight"), cover))
print()
print("apportioned %d of %d" % (total, budget))

sys.stderr.write("tenants=%d active=%d suspended=%d budget=%d apportioned=%d\n"
                 % (len(tenants), len(active), len(tenants) - len(active), budget, total))

if total != budget:
    sys.exit("apportioned %d against a budget of %d, the registry cannot settle it" % (total, budget))
