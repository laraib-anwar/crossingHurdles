# apportion

Works out each tenant's quota for a period, per allocation_policy.txt.
Run:

    python3 apportion.py tenants.csv usage_history.csv period.json

The table prints to stdout and one summary line goes to stderr as
tenants=N active=N suspended=N budget=N apportioned=N. The committed
allocation_2026_09.txt is the September run, a short note on what the
period looks like followed by the full table.

The apportionable amount is the pool less the reserve, and every call
in it is handed out. If your total comes to less than that, the
reason is almost always the same one described below.

Dividing once and clamping the results does not work, and September
shows it plainly. Seven tenants sit above their ceilings on the first
cut. Pin those seven and you have released a large block of calls back
to the six still free, whose shares climb well past where they
started, far enough that an eighth tenant tips over its own ceiling in
its turn. Run it as a single pass and the September table comes out
766,157 calls short of the apportionable amount, with every unpinned
tenant holding a number that is too small. The division has to repeat,
pinning one tenant at a time in registry order and redividing what is
left, until a whole pass finds nobody outside their range.

The order of pinning matters when several tenants breach at once. The
policy says take the first in registry order, redivide, then look
again, because pinning a different tenant first can change which of
the remaining ones ends up at a boundary. Do not pin all the
breaching tenants in one sweep to save a round.

Boundaries are inclusive, so a share landing
exactly on a ceiling or exactly on a floor is inside the range and the
tenant stays in the division. And the peak the table reports is the
tenant's highest single month in the supplied history, which for
several tenants is not their most recent month, so a tenant can be
shown under peak while its August usage sits comfortably under the
allocation.

The rounding remainder is small but it is not optional. Whole call
division leaves a few calls over once nobody is left to pin, and those
go one each to the largest fractional parts, lower tenant id winning a
tie. Skip that step and the total will be short by a handful of calls,
which is enough to fail reconciliation against billing. A leftover
call never lifts a tenant over its ceiling. When one is due to a
tenant already sitting exactly on its ceiling, that tenant is pinned
there like any other ceiling pin and what is left is divided again
among the rest. If every active tenant ends up pinned and the pins
still do not add up to the budget, the tool prints the table and the
summary line and then exits non zero naming both totals. Treat that
table as a diagnostic, not an allocation. A wrong number of arguments
or free tenants that all carry weight 0 also stop it with a non zero
exit.

Read the suspension rule before the numbers. A
suspended tenant is not allocated zero and then included in the
division anyway; its weight is left out of the total, so it never has
a share of its own. What stays in the pot is the calls it would have
taken, and those go to everybody else. That is why the ceilings bite
so hard in September. One growth tenant carrying a substantial weight
is suspended, and with its weight out of the total every remaining
tenant takes a larger share of the same budget on the first cut. That is what puts seven tenants over their ceilings before a
single pin has happened.

The stderr line is what the billing job greps, so its five fields and
their order are part of the contract rather than a convenience. It
reports the registry size, how many tenants were active, how many were
suspended, the apportionable amount after the reserve came off, and
the total actually handed out. Those last two agree in a correct run,
and a mismatch between them is the fastest signal that the division
stopped early.
