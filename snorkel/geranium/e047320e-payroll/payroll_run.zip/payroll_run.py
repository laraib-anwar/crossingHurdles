#!/usr/bin/env python3
# Weekly register for the placed warehouse staff, per pay_rules.txt.
#   python3 payroll_run.py employees.csv shifts.csv > register.txt
#   (then paste register.txt below the note in payroll_2026_0824.txt)
# Change both dates below when running a different week.

import csv
import sys
from datetime import datetime, timedelta

MONDAY = "2026-08-24"
SUNDAY = "2026-08-30"
NIGHT_DIFF = 150      # cents/hr, 22:00-06:00


def cents(mins, rate, halves):
    # halves: 2 = straight, 3 = time and a half, 4 = double.
    # amount = mins/60 * rate * halves/2, rounded half up (s.6). ints only,
    # no floats anywhere near money.
    num = mins * rate * halves
    return (num + 60) // 120


if len(sys.argv) != 3:
    sys.exit("usage: payroll_run.py employees.csv shifts.csv")

emp_order = []
base = {}
with open(sys.argv[1], newline="") as f:
    for r in csv.DictReader(f):
        e = r["emp_id"].strip()
        emp_order.append(e)
        base[e] = int(r["base_rate_cents"])

punches = []
with open(sys.argv[2], newline="") as f:
    for r in csv.DictReader(f):
        e, d = r["emp_id"].strip(), r["date"].strip()
        t_in = datetime.strptime(d + " " + r["start"].strip(), "%Y-%m-%d %H:%M")
        t_out = datetime.strptime(d + " " + r["end"].strip(), "%Y-%m-%d %H:%M")
        if t_out <= t_in:
            t_out += timedelta(days=1)   # overnight, still counts on d (s.1)
        punches.append((t_in, t_out, e, d))
punches.sort()

days_on = {e: set() for e in emp_order}
for t_in, t_out, e, d in punches:
    if e in days_on:
        days_on[e].add(d)
all7 = [e for e in emp_order if len(days_on[e]) == 7]

daymins = {}                 # (emp, date) -> minutes worked so far that day
wk_st = dict.fromkeys(emp_order, 0)   # straight minutes toward the forty
hrs = {e: [0, 0, 0] for e in emp_order}   # minutes at 1x, 1.5x, 2x
pay = dict.fromkeys(emp_order, 0)
hit40 = {}

for t_in, t_out, e, d in punches:
    if e not in base:
        continue
    lines = []               # this shift only, lines never cross shifts (s.6)
    t = t_in
    while t < t_out:
        n = daymins.get((e, d), 0)
        if e in all7 and d == SUNDAY:
            h = 4 if n >= 480 else 3            # s.5
        elif n >= 720:
            h = 4
        elif n >= 480:
            h = 3
        elif wk_st[e] >= 2400:
            h = 3                               # s.4, weekly forty
            if e not in hit40:
                hit40[e] = (d, t.strftime("%H:%M"))
        else:
            h = 2
            wk_st[e] += 1   # premium minutes never move the weekly count
        daymins[(e, d)] = n + 1

        r = base[e]
        if t.hour >= 22 or t.hour < 6:
            r += NIGHT_DIFF
        if lines and lines[-1][0] == h and lines[-1][1] == r:
            lines[-1][2] += 1
        else:
            lines.append([h, r, 1])
        t += timedelta(minutes=1)

    for h, r, m in lines:
        pay[e] += cents(m, r, h)
        hrs[e][h - 2] += m

tot_min = sum(sum(hrs[e]) for e in emp_order)
tot_pay = sum(pay.values())

print("payroll register, week of " + MONDAY)
print("employees %d, hours %.2f, gross %d" % (len(emp_order), tot_min / 60, tot_pay))
for e in emp_order:
    st, ot, dt = hrs[e]
    print()
    print("employee " + e)
    print("  straight %.2f, time and a half %.2f, double %.2f" % (st / 60, ot / 60, dt / 60))
    print("  gross %d" % pay[e])
print()
print("premium notes")
for e in emp_order:
    if e in all7:
        print("  %s worked all seven days, seventh day rule on %s" % (e, SUNDAY))
    if e in hit40:
        print("  %s passed forty straight hours during the %s shift at %s" % (e, hit40[e][0], hit40[e][1]))

sys.stderr.write("employees=%d hours=%.2f gross=%d over40=%d seventh=%d\n"
                 % (len(emp_order), tot_min / 60, tot_pay, len(hit40), len(all7)))
