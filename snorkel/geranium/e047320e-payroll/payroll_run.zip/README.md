# payroll_run

Builds the weekly payroll register from the punch record, per
pay_rules.txt. Run:

    python3 payroll_run.py employees.csv shifts.csv

The register goes to stdout and one line goes to stderr:

    employees=9 hours=304.40 gross=718006 over40=2 seventh=1

payroll_2026_0824.txt is that run, a short note first and then the
register in full: a block per employee with hours at each multiplier
and gross, then the premium notes.

What to watch for. The weekly forty counts straight hours only. An
hour already paid at a premium under the daily or seventh day rules
never advances the weekly count and is never paid twice. Two workers
cross the forty partway through a Saturday shift, w-1408 at 09:00 and
w-7214 at 14:00, so the weekly premium starts mid shift for both. Let
premium hours pyramid into the count and w-1408 reaches forty at half
past eight on the Friday, so the six and a half straight hours after
it collect a weekly premium they have not earned, and w-1408 starts
Saturday already past the line. w-7214 tips over five hours early on
the same Saturday. The register comes out 13625 cents heavy, 8250 of
it on w-1408 and 5375 on w-7214.

A shift that runs past midnight belongs entirely to the day it
started, hours and pay alike. Split the overnight shifts at midnight
and w-3117's daily overtime disappears, w-8093's overtime lands on the
wrong hours, and the register comes out 844 cents light.

The night differential attaches to minutes between ten at night and
six in the morning, joins the base rate, and every multiplier applies
to the combined rate. Add it after the multiplier instead and the
register is 376 cents light, which is exactly the kind of cent level
error the quarterly audit reads line by line.

Three workers have two shifts on the same day, w-7214 on three days
and w-8093 and w-9150 on one each, and the file lists every one of
those pairs out of clock order. The daily eight and twelve count across both
shifts, in clock order, so the later shift is the one that goes into
overtime. On Tuesday w-8093 works 16:00 to 19:00 and then 22:00 to
05:00: the first three hours and five of the night hours are straight,
and the last two night hours, 03:00 to 05:00, pay time and a half on
a combined rate of 20.25 dollars an hour, the 18.75 base plus the
night differential. Take the rows in file order instead and the overtime lands on
the afternoon at the day rate, and w-7214's Wednesday goes wrong the
same way. That costs 262 cents across the two.

Each pay line rounds half up on its own, one rate and one multiplier
at a time. If the punches change, rerun and diff against the
committed register before the bank file goes out.

w-1408 by hand, as a check on the tool. Base 2200 cents an hour, no
night minutes. Monday 07:00 to 16:30 is 8 straight and 1.5 at time and
a half. Tuesday 06:00 to 19:00 is 8 straight, 4 at time and a half and
1 double. Wednesday 07:00 to 14:00 is 7 straight. Thursday 07:00 to
16:00 is 8 straight and 1 at time and a half. Friday 07:00 to 15:30 is
8 straight and 0.5 at time and a half. The straight count runs 8, 16,
23, 31 and 39, so w-1408 reaches Saturday one hour short of the line.
Saturday 08:00 to 17:00 pays its first hour straight, which makes 40
at 09:00, then 7 hours at time and a half under the weekly forty and
the ninth hour at time and a half under the daily rule. The week is 40
straight, 15 time and a half and 1 double: 40 hours at 2200 is 88000,
15 at 3300 is 49500 and 1 at 4400 is 4400, 141900 cents in all, which
is what the register prints.

The committed run is the week beginning Monday 2026-08-24, which is
where the name payroll_2026_0824.txt comes from.

If you point this at a later week, two dates at the top of
payroll_run.py have to move with it. SUNDAY holds 2026-08-30, and the
seventh day premium is decided against it, so on a later week that
check would look at the wrong day and quietly pay nothing extra.
MONDAY holds 2026-08-24 and goes into the heading, week of 2026-08-24.
The seventh day note near the end of the file reads the same SUNDAY
value rather than a literal of its own, so it needs no edit. Change
the two together or the register will say one week and compute
another.
