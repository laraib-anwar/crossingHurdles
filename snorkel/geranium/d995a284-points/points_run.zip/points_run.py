#!/usr/bin/env python3
#   python3 points_run.py members.csv activity.csv > statement_2026_09.txt

import calendar
import csv
import sys
from datetime import date

if len(sys.argv) != 3:
    sys.exit("usage: points_run.py members.csv activity.csv")

CUT = date(2026, 9, 1)
ROLL_FROM = date(2025, 9, 1)
ROLL_TO = date(2026, 8, 31)
WARN_TO = date(2026, 10, 31)

def ymd(s):
    y, m, d = s.strip().split("-")
    return date(int(y), int(m), int(d))

def plus_months(d, n):
    # same day n months on, or the last day of that month if it is shorter
    y, m = divmod(d.month - 1 + n, 12)
    y, m = d.year + y, m + 1
    return date(y, m, min(d.day, calendar.monthrange(y, m)[1]))

with open(sys.argv[1], newline="") as fh:
    members = [r["member_id"].strip() for r in csv.DictReader(fh)]
with open(sys.argv[2], newline="") as fh:
    rows = [r for r in csv.DictReader(fh) if ymd(r["date"]) < CUT]

pots = {m: [] for m in members}      # [expires, earned, points, ref, row]
owed = {m: 0 for m in members}
earned = {m: {} for m in members}
reversed_refs = {m: set() for m in members}
refused = []

def draw(m, n):
    # s.3 soonest to expire first, then older earn, then file order
    pots[m].sort(key=lambda b: (b[0], b[1], b[4]))
    for b in pots[m]:
        k = min(b[2], n)
        b[2] -= k
        n -= k
        if n == 0:
            break
    pots[m] = [b for b in pots[m] if b[2] > 0]
    return n

def expire(day):
    for m in members:
        pots[m] = [b for b in pots[m] if b[0] > day]

days = []
by_day = {}
for i, r in enumerate(rows):
    r["row"] = i
    d = ymd(r["date"])
    if d not in by_day:
        by_day[d] = []
        days.append(d)
    by_day[d].append(r)

for day in sorted(days):
    expire(day)
    for r in by_day[day]:
        m = r["member"].strip()
        kind = r["kind"].strip()
        n = int(r["points"])
        ref = r["ref"].strip()
        if kind in ("earn", "bonus"):
            paid = min(owed[m], n)
            owed[m] -= paid
            if n > paid:
                life = 12 if kind == "earn" else 3
                pots[m].append([plus_months(day, life), day, n - paid, ref, r["row"]])
            earned[m][ref] = (day, n, kind)
        elif kind == "spend":
            if n > sum(b[2] for b in pots[m]):
                refused.append((day, m, n))
            else:
                draw(m, n)
        elif kind == "reversal":
            left = earned[m][ref][1]
            for b in pots[m]:
                if b[3] == ref:
                    left -= b[2]
                    b[2] = 0
                    break
            pots[m] = [b for b in pots[m] if b[2] > 0]
            owed[m] += draw(m, left)
            reversed_refs[m].add(ref)

expire(CUT)

total = 0
expiring = 0
gold = silver = 0
blocks = []
for m in members:
    bal = sum(b[2] for b in pots[m])
    total += bal
    soon = {}
    for b in pots[m]:
        if b[0] <= WARN_TO:
            soon[b[0]] = soon.get(b[0], 0) + b[2]
    expiring += sum(soon.values())
    roll = 0
    for ref, (d, p, kind) in earned[m].items():
        # s.5 only earns count toward tier, bonus points never do
        if kind == "earn" and ROLL_FROM <= d <= ROLL_TO and ref not in reversed_refs[m]:
            roll += p
    if roll >= 50000:
        tier = "gold"
        gold += 1
    elif roll >= 25000:
        tier = "silver"
        silver += 1
    else:
        tier = "member"
    b = ["member " + m, "  balance %d" % bal]
    if owed[m]:
        b.append("  owed %d" % owed[m])
    for w in sorted(soon):
        b.append("  expiring %s  %d" % (w.isoformat(), soon[w]))
    b.append("  rolling earn %d, tier %s" % (roll, tier))
    blocks.append(b)

all_owed = sum(owed.values())
print("september statement run from activity.csv")
print("members %d, points on the books %d, owed %d, gold %d, silver %d"
      % (len(members), total, all_owed, gold, silver))
for b in blocks:
    print()
    print("\n".join(b))
print()
print("refused spends")
for d, m, n in refused:
    print("  %s  %-6s asked %d" % (d.isoformat(), m, n))

print("members=%d balance=%d owed=%d expiring=%d gold=%d silver=%d refused=%d"
      % (len(members), total, all_owed, expiring, gold, silver, len(refused)), file=sys.stderr)
