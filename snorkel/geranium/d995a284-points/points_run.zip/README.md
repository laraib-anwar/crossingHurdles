# points_run

Works the program's activity history into the September statement,
per points_rules.txt. Run:

    python3 points_run.py members.csv activity.csv

The statement goes to stdout and one line goes to stderr:

    members=12 balance=297889 owed=7332 expiring=49627 gold=1 silver=5 refused=3

statement_2026_09.txt is that run, a short note first and then the
statement in full: a block per member with balance, owed points,
expiring buckets, rolling earn and tier, then the refused spends.

What to watch for. Spends drain the live bucket that expires soonest,
and that ordering decides everything downstream: which buckets
survive, what expires in September and October, and what a reversal
can still find. For flying earns the soonest is also the oldest, but a
bonus bucket lives three months and jumps the queue. Draw newest
first and this history closes at 273678 points on the books, 24211
too low, with 10213 owed instead of 7332.

Bonus buckets are counted in calendar months, clamped to the end of a
short month, and never count toward tier. m-8255 shows all three. Its
bonus b-0108 from 2025-11-30 dies at the start of 2026-02-28, so the
4100 spend that day comes out of e-0612, leaving 10110 to expire on
2026-09-18. b-0131 from 2026-03-31 lives until the start of
2026-06-30, so the 2400 spend on 2026-06-29 takes it rather than
e-0612; count 90 days instead and that bucket is already gone and
e-0612 drops to 7710. Its rolling earn is 23975 from flying alone,
which leaves it at member; add the 7300 bonus points and it would
wrongly show silver. m-9031's spend on 2026-05-06 takes its bonus
first because it expires a week before the older earn does.

The statement cut is a boundary on both sides. m-4076 earned 1300
points on 2025-09-01. That is the first day of the rolling year, so
the earn counts toward the tier and lifts m-4076 to 25064 and silver.
The same bucket dies at the start of 2026-09-01, which is the morning
the statement is drawn, so none of those points are in the balance or
in the expiring lines. Leave out that morning's expiries and the
balance is wrong; start the rolling year a day late and m-4076 drops
back to member.

Expiries run at the start of a day, before any of that day's rows.
Three spends here land on the very day a bucket dies, for m-4633,
m-8255 and m-9031, and each has to draw from the buckets still live.
Run expiries at the end of the day instead and those spends draw from
buckets that should already be gone, which overstates the three
closing balances by 2000, 3000 and 3000 points and the program total
by 8000.

Reversals take back a named earn, the whole of it. What is still
unspent in that bucket goes first, the shortfall comes from the other
live buckets in the order a spend would draw them, soonest to expire
first, and anything past that becomes owed points
that later earns work down before the rest is added to the balance.
Treat a reversal as a plain subtraction and the expiring totals drift,
because the wrong buckets survive.

A spend larger than the live balance is refused and changes nothing.
Three of those sit in this history and they are all on the statement.

One activity row is dated after the statement cut. It has not
happened for this statement and is ignored entirely; process it and
three members' balances and the whole expiring block corrupt, which
is the first thing to check if a rebuild disagrees.

m-3521 by hand, since that is the owed figure finance will ask about.
The 30000 point earn e-0551 lands on 2025-08-20. The member's three
spends drain older buckets first: 655 and 699 come out of e-0228, and
the 1527 on 2026-07-15 takes the last 1347 of e-0232 and only 180 of
e-0551. So e-0551 still holds 29820 when it expires on the morning of
2026-08-20. The reversal on 2026-08-25 takes back all 30000, but none
of that bucket is live any more, so the whole amount comes from the
other buckets, soonest to expire first. They hold 20168 between them, all of it
goes, and 9832 is left owed. The 2500 earn on 2026-08-29 pays that
down to 7332 and creates no bucket. The statement shows m-3521 at
balance 0 and owed 7332, which is what the tool prints.

If the activity file changes, rerun and diff against the committed
statement before release. The per member blocks move before the
totals visibly do.
