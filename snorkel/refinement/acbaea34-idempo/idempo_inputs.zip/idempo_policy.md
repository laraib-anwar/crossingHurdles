# Manitowoc Claims Cloud — Intake Idempotency Policy

Document: POL-MCC-INTAKE-IDMP-2026-09
Product: Manitowoc Claims Cloud
Applies to: intake v3 write path (POST, PUT, PATCH)
Effective: 2026-09-01

## 1. Authority

`idempo_policy.md` is the keying and retention rule for production intake.
`counsel_slack.txt` is conversation, not policy. `cut_plan.json` names the
release, the compare timestamp, and the pause; it does not define how keys
are built.

## 2. Store key

Lookup is always the pair (tenant_id, store_key). A store record created for
one tenant_id must never be returned to a different tenant_id.

If the request carries a non-empty Idempotency-Key header, that header string
(trimmed) is the store_key. Do not hash the body when the header is present.
Whitespace and JSON key order must not create a second draft when the header
matches.

If the header is absent, build the store_key as the SHA-256 hex digest of
these UTF-8 bytes: the canonical JSON body, then ASCII unit separator 0x1F,
then the tenant_id. Canonical JSON means a parsed object re-serialized with
object keys sorted alphabetically and no extra whitespace
(separators comma and colon only).

Exact tenant_id match after lowercasing the tenant_index.csv tenant_id column
is required when deciding production vs sandbox.

## 3. TTL

Financial drafts remain replayable for at least 24 hours from created_at using
the full timestamp, not the calendar date alone. intake_config.json may raise
ttl_hours above 24. It must not lower the floor. A config value below 24 hours
is a non-conformance; implementations must clamp up to 24, not honor the
lower value.

## 4. Methods

POST, PUT, and PATCH may create a store record on a miss.
GET, HEAD, and OPTIONS must not create a store record. A safe method may
return an existing live record; it may not insert a new one.

## 5. Scope

tenant_index.csv environment=sandbox tenants are out of scope for the
production intake-v3 cut. Do not count sandbox rows in production duplicate
or cross-tenant totals.

## 6. SDK retries

Mobile clients retry timed-out POSTs and may emit the same object with a
different JSON key order or different spacing. When Idempotency-Key is
present, those retries are one intake.

## 7. Pause rule

If production traffic shows (a) two live drafts for one policy key or (b) a
store hit that crossed tenant_id values, the intake-v3 cut stays paused until
the evaluator is patched and Tuesday's window is replayed clean.

## 8. Reporting

Count TTL-misapplied rows as production retry requests which, at received_at,
missed an already-created matching record solely because its age exceeded the
configured six-hour TTL while remaining within the required 24-hour retention
period. Count the retry request, not the original store row. cut_plan.json
as_of is a reporting cutoff only.
