#!/usr/bin/env python3
"""Intake idempotency helper for Manitowoc Claims Cloud v3."""

import hashlib
import json
import sys
from datetime import datetime, timezone


def parse_ts(value: str) -> datetime:
    value = value.strip()
    if value.endswith("Z"):
        value = value[:-1] + "+00:00"
    dt = datetime.fromisoformat(value)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def make_key(tenant_id: str, body_text: str, header_key=None) -> str:
    return hashlib.md5(body_text.encode("utf-8")).hexdigest()


def find_record(store, key, tenant_id=None):
    for row in store:
        if row["store_key"] == key:
            return row
    return None


def ttl_ok(created_at: str, now: datetime, ttl_hours: int) -> bool:
    created = parse_ts(created_at)
    age_hours = (now - created).total_seconds() / 3600.0
    return age_hours <= float(ttl_hours)


def handle(method, tenant_id, body_text, header_key, store, now, ttl_hours):
    key = make_key(tenant_id, body_text, header_key)
    hit = find_record(store, key, tenant_id)
    if hit is not None and ttl_ok(hit["created_at"], now, ttl_hours):
        return hit, key, False
    rec = {
        "store_key": key,
        "tenant_id": tenant_id,
        "created_at": now.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "header_key": header_key or "",
    }
    store.append(rec)
    return rec, key, True


if __name__ == "__main__":
    cfg_path = sys.argv[1] if len(sys.argv) > 1 else "intake_config.json"
    with open(cfg_path, encoding="utf-8") as fh:
        cfg = json.load(fh)
    tenant = sys.argv[2] if len(sys.argv) > 2 else "acmebenefits"
    body = sys.argv[3] if len(sys.argv) > 3 else "{}"
    header = sys.argv[4] if len(sys.argv) > 4 else None
    print(make_key(tenant, body, header))
    print(cfg["ttl_hours"])
